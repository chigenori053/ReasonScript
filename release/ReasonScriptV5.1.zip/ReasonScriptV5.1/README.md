# ReasonScriptV5.1

ReasonScript 0.5.1 の macOS Apple Silicon（arm64）向け配布パッケージです。

## 収録内容

- `reasonscript-0.5.1-macos-arm64.tar.gz` — 公式形式の更新・インストールアーカイブ
- `reasonscript-0.5.1-macos-arm64.tar.gz.sha256` — アーカイブの SHA-256
- `reasonscript-0.5.1-macos-arm64.manifest.json` — ビルド元・収録ファイル・整合性情報
- `reasonscript-0.5.1-macos-arm64.manifest.sha256` — マニフェストの SHA-256

## 確認済み情報

- Source commit: `d47aa233880660914c948435658dc631026ad61b`
- Source state: clean
- Package class: release
- Files: 422
- Freshness: fresh
- Package validation: pass
- Payload SHA-256: `79997026f9f712848ab12e49496737e551c6b4b8f16ddcbefbeb42bac9438fda`
- Archive SHA-256: `1a52552ea7e1e431df17e80f252ed9660a51c5852efe451eb793042e187dd9eb`

新規の ReasonUnit Object、File、Language、Migration、Runtime、Tensor、および関連スキーマを収録しています。

アーカイブ本体は検証上の正式名称を維持しています。配布時は、この `ReasonScriptV5.1` フォルダまたは外側の `ReasonScriptV5.1.zip` を使用してください。
