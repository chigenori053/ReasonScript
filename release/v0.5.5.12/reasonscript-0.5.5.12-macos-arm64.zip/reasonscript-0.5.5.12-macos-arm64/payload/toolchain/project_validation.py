"""Standalone ReasonScript project validation (ICRIR section 17)."""

from __future__ import annotations

import hashlib
import json
import tomllib
from pathlib import Path
from typing import Any

from frontend.language_surface.nodes import CalculationNode
from toolchain.pipeline import PipelineError, compile_package_sources
from toolchain.runtime_dispatch import RustDispatchError, execute_rust_program
from toolchain.artifacts import validate_artifact_directory
from toolchain.manifest import Manifest, ManifestError
from toolchain.source_selection import SourceSelectionError, package_sources

SCHEMA_VERSION = "reasonscript-project-validation/0.1"


def validate_project(root: str | Path, *, repetitions: int = 3) -> dict[str, Any]:
    project_root = Path(root).resolve()
    diagnostics: list[dict[str, Any]] = []
    phases: list[dict[str, Any]] = []

    manifest_path = project_root / "reason.toml"
    manifest: Manifest | None = None
    if not manifest_path.is_file():
        diagnostics.append(_diagnostic("PV-001", "Missing project manifest: reason.toml"))
    else:
        try:
            manifest = Manifest.load(project_root)
        except (OSError, ManifestError, tomllib.TOMLDecodeError) as error:
            diagnostics.append(_diagnostic("PV-002", f"Invalid project manifest: {error}"))
    phases.append(_phase("manifest_validation", manifest is not None))

    try:
        sources = package_sources(project_root, manifest) if manifest is not None else []
    except SourceSelectionError as error:
        diagnostics.append(_diagnostic(error.code, str(error)))
        sources = []
    if not sources:
        diagnostics.append(_diagnostic("PV-003", "No .rsn sources found in src/"))
    phases.append(_phase("source_discovery", bool(sources), count=len(sources)))

    passed = 0
    runtime_total = 0
    runtime_passed = 0
    canonical_runs: list[str] = []
    if sources:
        try:
            compiled = compile_package_sources(
                [(path.read_text(encoding="utf-8"), path) for path in sources]
            )
            passed = len(sources)
            if not compiled.reason_irs:
                diagnostics.append(
                    _diagnostic("PV-005", "Reason IR was not generated for the package")
                )
            runtime_total = int(
                any(
                    isinstance(item, CalculationNode)
                    for module in compiled.surface_ast.modules
                    for item in module.body
                )
            )
            if runtime_total:
                run_hashes = []
                for _ in range(repetitions):
                    payload = execute_rust_program(
                        compiled.surface_ast,
                        project_root,
                        False,
                        False,
                        backend=_manifest_backend(manifest),
                    )
                    encoded = _canonical(payload)
                    run_hashes.append(hashlib.sha256(encoded.encode()).hexdigest())
                canonical_runs.extend(run_hashes)
                if len(set(run_hashes)) == 1:
                    runtime_passed = runtime_total
                else:
                    diagnostics.append(
                        _diagnostic(
                            "PV-008", "Non-deterministic package runtime result"
                        )
                    )
        except PipelineError as error:
            diagnostics.append(_diagnostic("PV-004", f"{error.code}: {error.message}"))
        except RustDispatchError as error:
            diagnostics.append(_diagnostic("PV-004", f"{error.code}: {error.message}"))
        except Exception as error:
            diagnostics.append(_diagnostic("PV-004", f"package runtime: {error}"))
    phases.append(_phase("source_check", passed == len(sources), count=passed))
    phases.append(_phase("semantic_validation", passed == len(sources)))
    phases.append(_phase("runtime_execution", runtime_passed == runtime_total, count=runtime_passed))

    artifact_ok = _artifact_contract(project_root, diagnostics)
    phases.append(_phase("artifact_validation", artifact_ok))
    golden_ok = _golden_contract(project_root, diagnostics)
    phases.append(_phase("golden_comparison", golden_ok))
    determinism_ok = runtime_passed == runtime_total
    phases.append(_phase("determinism_validation", determinism_ok, repetitions=repetitions))
    tests_ok = _project_tests_contract(project_root, diagnostics)
    phases.append(_phase("project_local_tests", tests_ok))

    ok = not diagnostics
    report = {
        "schema_version": SCHEMA_VERSION,
        "status": "passed" if ok else "failed",
        "project_root": str(project_root),
        "sources_total": len(sources),
        "sources_passed": passed,
        "runtime_cases_total": runtime_total,
        "runtime_cases_passed": runtime_passed,
        "artifact_validation_passed": artifact_ok,
        "golden_validation_passed": golden_ok,
        "determinism_passed": determinism_ok,
        "tests_passed": tests_ok,
        "repository_workflow_required": False,
        "phases": phases,
        "canonical_hashes": canonical_runs,
        "diagnostics": diagnostics,
    }
    return report


def _manifest_backend(manifest: Manifest | dict[str, Any] | None) -> str:
    if isinstance(manifest, Manifest):
        return manifest.backend
    if not isinstance(manifest, dict):
        return "RuntimeReal"
    runtime = manifest.get("runtime", {})
    if isinstance(runtime, dict) and isinstance(runtime.get("backend"), str):
        return runtime["backend"]
    if isinstance(manifest.get("backend"), str):
        return manifest["backend"]
    return "RuntimeReal"


def write_project_validation_report(root: Path, report: dict[str, Any]) -> Path:
    output = root / "artifacts" / "phase_1r" / "project_validation"
    output.mkdir(parents=True, exist_ok=True)
    path = output / "project_validation_report.json"
    path.write_text(_canonical(report), encoding="utf-8")
    return path


def _artifact_contract(root: Path, diagnostics: list[dict[str, Any]]) -> bool:
    # Standalone projects are not required to have pre-existing generated
    # artifacts. If they do, a manifest must accompany them.
    artifact_root = root / "artifacts"
    existing = [path for path in artifact_root.rglob("*.json")] if artifact_root.is_dir() else []
    if not existing:
        return True
    manifests = [path for path in existing if path.name in {"manifest.json", "artifact_manifest.json"}]
    generated_only = all("phase_1r/project_validation" in path.as_posix() for path in existing)
    if not manifests and not generated_only:
        diagnostics.append(_diagnostic("PV-006", "Artifact JSON exists without a manifest"))
        return False
    if generated_only:
        return True
    # Reuse the canonical validator: a recognized manifest name alone is not
    # a contract.  Both historical spellings are checked identically.
    document = validate_artifact_directory(artifact_root)
    for diagnostic in document.get("diagnostics", []):
        diagnostics.append(_diagnostic("PV-006", diagnostic.get("message", "invalid artifact")))
    return not document.get("diagnostics")


def _golden_contract(root: Path, diagnostics: list[dict[str, Any]]) -> bool:
    golden = root / "golden"
    if not golden.exists():
        return True
    if not golden.is_dir():
        diagnostics.append(_diagnostic("PV-007", "golden must be a directory"))
        return False
    return True


def _project_tests_contract(root: Path, diagnostics: list[dict[str, Any]]) -> bool:
    tests = root / "tests"
    if not tests.exists():
        return True
    if not tests.is_dir():
        diagnostics.append(_diagnostic("PV-009", "tests must be a directory"))
        return False
    return True


def _has_loop(path: Path) -> bool:
    source = path.read_text(encoding="utf-8")
    return any(token in source for token in ("for ", "while ", "loop {"))


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def _diagnostic(code: str, message: str) -> dict[str, Any]:
    return {"code": code, "severity": "error", "category": "project_validation", "message": message}


def _phase(name: str, ok: bool, **details: Any) -> dict[str, Any]:
    return {"phase": name, "status": "passed" if ok else "failed", **details}
