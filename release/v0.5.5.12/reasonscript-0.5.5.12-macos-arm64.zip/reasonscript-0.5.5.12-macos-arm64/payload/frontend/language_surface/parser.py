"""Deterministic block parser for the Phase 1.1 surface."""

from __future__ import annotations

import re
from collections import defaultdict, deque
from contextvars import ContextVar
from dataclasses import dataclass
from dataclasses import fields, is_dataclass
from pathlib import PurePosixPath

from .expressions import (
    MAX_PATTERN_DEPTH,
    ExpressionSyntaxError,
    parse_expression,
    parse_pattern,
)
from .lexer import tokenize
from .namespace import NamespaceResolutionError, resolve_program
from .nodes import (
    ActionNode,
    ArrayLiteralNode,
    ArrayTypeNode,
    AssignmentStatementNode,
    AttributeNode,
    BinaryExpressionNode,
    BreakStatementNode,
    CalculationNode,
    CallExpressionNode,
    ComparisonExpressionNode,
    ConceptNode,
    ConstDeclarationNode,
    ConstraintNode,
    ConstStatementNode,
    ContinueStatementNode,
    ElseIfStatementNode,
    ElseStatementNode,
    EnumDeclarationNode,
    EnumValueNode,
    EventNode,
    ExecutionPlanDeclarationNode,
    ExpressionNode,
    ExpressionStatementNode,
    FieldAssignmentStatementNode,
    ForStatementNode,
    FunctionDeclarationNode,
    GoalNode,
    GoalStatementNode,
    IdentifierNode,
    IfStatementNode,
    ImportNode,
    IndexAccessNode,
    IndexAssignmentStatementNode,
    LetStatementNode,
    LogicalExpressionNode,
    LoopStatementNode,
    MapEntryNode,
    MapLiteralNode,
    MapTypeNode,
    MatchArmNode,
    MatchStatementNode,
    MemberAccessNode,
    ModuleNode,
    NamedTypeNode,
    ObjectNode,
    OptionalTypeNode,
    PackageDeclarationNode,
    ParenthesizedExpressionNode,
    PlanStepNode,
    PrimitiveKind,
    PrimitiveTypeNode,
    ProgramNode,
    ReachStatementNode,
    ReasonGraphDeclarationNode,
    ReasonGraphBindingNode,
    ReasonGraphTransitionNode,
    ReasonObjectBindingNode,
    ReasonObjectClauseSpanNode,
    RelationNode,
    RelationType,
    RequireStatementNode,
    ResultStatementNode,
    ReturnStatementNode,
    RuntimeCallExpressionNode,
    RuntimeCallKind,
    RuntimeNamespaceNode,
    SetLiteralNode,
    SetTypeNode,
    SomeExpressionNode,
    SourceSpanNode,
    StateDeclarationNode,
    StateKind,
    StateTypeNode,
    StructDeclarationNode,
    StructFieldNode,
    StructLiteralFieldNode,
    StructLiteralNode,
    TransitionNode,
    TupleLiteralNode,
    TupleTypeNode,
    UnaryExpressionNode,
    Visibility,
    WhileStatementNode,
)
from .validation import SurfaceValidationError, validate


class SurfaceSyntaxError(ValueError):
    pass


class SurfaceReservedConstructError(SurfaceSyntaxError):
    code = "LL-002-RESERVED-TOP-LEVEL-CONSTRUCT"
    layer = "L1"
    severity = "error"

    def __init__(self, construct: str) -> None:
        self.construct = construct
        super().__init__(_reserved_construct_message(construct))


_RESERVED_TOP_LEVEL_CONSTRUCTS = {
    "world": "WorldModel syntax",
    "system": "multi-model orchestration",
    "component": "UI / SDK structural composition",
}


def _reserved_construct_message(construct: str) -> str:
    purpose = _RESERVED_TOP_LEVEL_CONSTRUCTS[construct]
    return (
        f"{construct} is reserved for future {purpose} "
        "and is not active in v0.6-D."
    )


@dataclass
class _Cursor:
    lines: list[str]
    locations: list[tuple[int, int, str]]
    index: int = 0

    def current(self) -> str:
        if self.index >= len(self.lines):
            raise SurfaceSyntaxError("unexpected end of source")
        return self.lines[self.index]

    def take(self) -> str:
        value = self.current()
        _CURRENT_SOURCE_LINE.set(self.locations[self.index])
        self.index += 1
        return value


_CURRENT_SOURCE_LINE: ContextVar[tuple[int, int, str] | None] = ContextVar(
    "reasonscript_current_source_line",
    default=None,
)


def parse(source: str) -> ProgramNode:
    program = parse_unresolved(source)
    source_locations = _source_location_index(program)
    try:
        program, _ = resolve_program(program)
        _restore_source_locations(program, source_locations)
        validate(program)
    except (SurfaceValidationError, NamespaceResolutionError) as error:
        raise SurfaceSyntaxError(str(error)) from error
    return program


def parse_unresolved(source: str) -> ProgramNode:
    """Parse one source unit without requiring imported modules to be present.

    Package compilation combines all returned units into one closed
    :class:`ProgramNode` before namespace and type validation.  ``parse``
    remains the closed-program entry point for standalone callers.
    """
    try:
        tokenize(source)
    except ValueError as error:
        raise SurfaceSyntaxError(str(error)) from error
    logical_lines, locations = _logical_lines(source)
    cursor = _Cursor(logical_lines, locations)
    modules: list[ModuleNode] = []
    package: PackageDeclarationNode | None = None
    while cursor.index < len(cursor.lines):
        if cursor.current().startswith("package "):
            if modules or package is not None:
                raise SurfaceSyntaxError("PV-3 PackageMustAppearFirst")
            package = _parse_package(cursor)
            continue
        _reject_reserved_top_level_construct(cursor.current())
        modules.append(_parse_module(cursor))
    return ProgramNode(tuple(modules), package)


def _source_location_index(
    value,
) -> dict[tuple[type, str], deque[dict[str, int]]]:
    locations: dict[tuple[type, str], deque[dict[str, int]]] = defaultdict(deque)

    def visit(item) -> None:
        if not is_dataclass(item):
            return
        location = getattr(item, "_source_location", None)
        if isinstance(item, CallExpressionNode) and location is not None:
            locations[(type(item), repr(item))].append(dict(location))
        for descriptor in fields(item):
            child = getattr(item, descriptor.name)
            if isinstance(child, tuple):
                for element in child:
                    visit(element)
            else:
                visit(child)

    visit(value)
    return locations


def _restore_source_locations(
    value,
    locations: dict[tuple[type, str], deque[dict[str, int]]],
) -> None:
    def visit(item) -> None:
        if not is_dataclass(item):
            return
        if isinstance(item, CallExpressionNode):
            candidates = locations.get((type(item), repr(item)))
            if candidates:
                object.__setattr__(item, "_source_location", candidates.popleft())
        for descriptor in fields(item):
            child = getattr(item, descriptor.name)
            if isinstance(child, tuple):
                for element in child:
                    visit(element)
            else:
                visit(child)

    visit(value)


def _parse_package(cursor: _Cursor) -> PackageDeclarationNode:
    match = re.fullmatch(r"package\s+([A-Za-z_][A-Za-z0-9_]*)", cursor.take())
    if not match:
        raise SurfaceSyntaxError("PV-1 invalid package declaration")
    return PackageDeclarationNode(match.group(1))


def _reject_reserved_top_level_construct(line: str) -> None:
    if re.match(r"reason_object\b", line):
        raise SurfaceSyntaxError("RUO-N2-002 reason_object is a nested declaration only")
    match = re.fullmatch(
        r"(?:(?:pub)\s+)?(world|system|component)\b.*",
        line,
    )
    if match:
        raise SurfaceReservedConstructError(match.group(1))


def _paren_events(line: str) -> list[tuple[str, int]]:
    events: list[tuple[str, int]] = []
    quote: str | None = None
    escaped = False
    for column, char in enumerate(line, start=1):
        if quote is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = None
            continue
        if char in {'"', "'"}:
            quote = char
        elif char == "(":
            events.append((char, column))
        elif char == ")":
            events.append((char, column))
    return events


def _logical_lines(
    source: str,
) -> tuple[list[str], list[tuple[int, int, str]]]:
    lines: list[str] = []
    locations: list[tuple[int, int, str]] = []
    pending: str | None = None
    pending_line = 0
    pending_column = 1
    paren_depth = 0
    paren_openings: list[tuple[int, int]] = []
    for line_number, raw in enumerate(source.splitlines(), start=1):
        uncommented = _strip_line_comment(raw)
        line = uncommented.strip()
        if not line:
            continue
        # A trailing backslash continues a Code statement on the next physical
        # line. Parenthesized expressions also continue across newlines.
        # Insert whitespace so tokens from adjacent lines never merge.
        base_column = len(uncommented) - len(uncommented.lstrip()) + 1
        if pending is not None:
            line = f"{pending} {line}"
        else:
            pending_line, pending_column = line_number, base_column

        for event, column in _paren_events(uncommented):
            if event == "(":
                paren_openings.append((line_number, column))
            elif not paren_openings:
                raise SurfaceSyntaxError(
                    f"EX-V003 unbalanced parentheses: unexpected ')' at "
                    f"{line_number}:{column}"
                )
            else:
                paren_openings.pop()
        paren_depth = len(paren_openings)

        if line.endswith("\\") or paren_depth > 0:
            if line.endswith("\\"):
                pending = line[:-1].rstrip()
            else:
                pending = line
            continue
        effective_line_number = pending_line
        effective_base_column = pending_column
        pending = None
        paren_depth = 0
        line = re.sub(r"}\s*(elif\b)", r"}\n\1", line)
        line = re.sub(r"}\s*(else\b)", r"}\n\1", line)
        for part in (part.strip() for part in line.splitlines() if part.strip()):
            lines.append(part)
            locations.append((effective_line_number, effective_base_column + max(line.find(part), 0), part))
    if pending is not None:
        if paren_depth > 0:
            opening_line, opening_column = paren_openings[0]
            raise SurfaceSyntaxError(
                f"EX-V003 unbalanced parentheses: unclosed '(' starting at "
                f"{opening_line}:{opening_column}"
            )
        raise SurfaceSyntaxError(
            f"line continuation at {pending_line}:{pending_column} is missing a following line"
        )
    return lines, locations


def _strip_line_comment(raw: str) -> str:
    quote: str | None = None; escaped = False; index = 0
    while index < len(raw):
        char = raw[index]
        if quote is not None:
            if escaped: escaped = False
            elif char == "\\": escaped = True
            elif char == quote: quote = None
        elif char in {'"', "'"}: quote = char
        elif raw.startswith("//", index): return raw[:index]
        index += 1
    return raw


def _parse_module(cursor: _Cursor) -> ModuleNode:
    match = re.fullmatch(
        r"(?:(pub)\s+)?(module|model)\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{",
        cursor.take(),
    )
    if not match:
        raise SurfaceSyntaxError("expected module or model declaration")
    visibility = Visibility.PUBLIC if match.group(1) else Visibility.PRIVATE
    body = _parse_body(cursor, context="module")
    return ModuleNode(match.group(3), visibility, tuple(body), match.group(2))


def _parse_body(cursor: _Cursor, *, context: str) -> list:
    nodes: list = []
    while cursor.index < len(cursor.lines):
        line = cursor.current()
        if line == "}":
            cursor.index += 1
            return nodes
        if line.startswith("export import "):
            raise SurfaceSyntaxError("UnsupportedFeature")
        if line.startswith("export ") and context != "module":
            raise SurfaceSyntaxError("ExportMustBeTopLevel")
        if line.startswith("struct ") or line.startswith("export struct "):
            nodes.append(_parse_struct(cursor))
        elif line.startswith("enum ") or line.startswith("export enum "):
            nodes.append(_parse_enum(cursor))
        elif _is_collection_literal_statement(line):
            nodes.append(_parse_collection_literal_statement(cursor))
        elif _is_struct_literal_statement(line):
            nodes.append(_parse_struct_literal_statement(cursor))
        elif line.startswith("goal ") and line.endswith("{"):
            nodes.append(_parse_goal_declaration(cursor, context=context))
        elif line.startswith("state ") and line.endswith("{"):
            nodes.append(_parse_state_declaration(cursor))
        elif line.startswith("constraint ") and line.endswith("{"):
            nodes.append(_parse_constraint_declaration(cursor))
        elif line.startswith("transition "):
            nodes.append(_parse_transition(cursor))
        elif line.startswith("reason_graph "):
            nodes.append(_parse_reason_graph_binding(cursor) if " from " in line else _parse_reason_graph(cursor))
        elif line.startswith("reason_object "):
            if context != "module":
                raise SurfaceSyntaxError("RUO-N2-002 invalid reason_object lexical context")
            nodes.append(_parse_reason_object(cursor))
        elif line.startswith("execution_plan "):
            nodes.append(_parse_execution_plan(cursor))
        elif (
            line.startswith("calculation ")
            or line.startswith("pub calculation ")
            or line.startswith("export calculation ")
        ):
            nodes.append(_parse_calculation(cursor))
        elif (
            line.startswith("fn ")
            or line.startswith("pub fn ")
            or line.startswith("export fn ")
        ):
            nodes.append(_parse_function(cursor))
        elif line.startswith("for "):
            nodes.append(_parse_for(cursor, context=context))
        elif line.startswith("while "):
            nodes.append(_parse_while(cursor, context=context))
        elif line == "loop {":
            nodes.append(_parse_loop(cursor, context=context))
        elif line.startswith("if "):
            nodes.append(_parse_if(cursor, context=context))
        elif line.startswith("match "):
            nodes.append(_parse_match(cursor, context=context))
        else:
            nodes.append(_parse_simple(_collect_simple_statement(cursor), context=context))
    raise SurfaceSyntaxError(f"unterminated {context} block")


def _parse_reason_object(cursor: _Cursor) -> ReasonObjectBindingNode:
    start_index = cursor.index
    parts = [cursor.take().rstrip(";")]
    while cursor.index < len(cursor.lines):
        following = cursor.current().rstrip(";")
        if re.match(r"^(resources|mode|as)\b", following):
            parts.append(cursor.take().rstrip(";"))
        else:
            break
    text = " ".join(parts)
    head = re.match(
        r'^reason_object\s+([A-Za-z_][A-Za-z0-9_]*)\s+from\s+("(?:[^"\\]|\\.)*")(?=\s|$)',
        text,
    )
    if not head:
        raise SurfaceSyntaxError("RUO-N2-003 reason_object requires an identifier and string from path")
    name, source_literal = head.group(1), head.group(2)
    source_path = _reason_object_string(source_literal)
    tail = text[head.end():].strip()
    clauses: dict[str, str] = {}
    clause_spans: list[ReasonObjectClauseSpanNode] = [
        ReasonObjectClauseSpanNode("name", SourceSpanNode(start_index + 1, 15, start_index + 1, 15 + len(name))),
        ReasonObjectClauseSpanNode("from", SourceSpanNode(start_index + 1, max(1, parts[0].find("from") + 1), start_index + 1, len(parts[0]) + 1)),
    ]
    clause_pattern = re.compile(r'^(resources|mode|as)\s+("(?:[^"\\]|\\.)*"|strict|preserve)(?=\s|$)')
    while tail:
        match = clause_pattern.match(tail)
        if not match:
            raise SurfaceSyntaxError("RUO-N2-003 unknown or malformed reason_object clause")
        clause, value = match.group(1), match.group(2)
        if clause in clauses:
            raise SurfaceSyntaxError(f"RUO-N2-003 duplicate reason_object clause: {clause}")
        clauses[clause] = value
        logical_line = start_index + 1 + min(len(clause_spans) - 1, len(parts) - 1)
        clause_spans.append(ReasonObjectClauseSpanNode(clause, SourceSpanNode(logical_line, 1, logical_line, len(match.group(0)) + 1)))
        tail = tail[match.end():].strip()
    mode = clauses.get("mode", "strict")
    if mode not in {"strict", "preserve"}:
        raise SurfaceSyntaxError("RUO-N2-003 unknown reason_object load mode")
    resource_root = _reason_object_string(clauses["resources"]) if "resources" in clauses else None
    expected = _reason_object_string(clauses["as"]) if "as" in clauses else None
    _validate_reason_object_path(source_path)
    if not source_path.endswith(".ruo"):
        raise SurfaceSyntaxError("RUO-N2-006 reason_object source must use lowercase .ruo")
    if resource_root is not None: _validate_reason_object_path(resource_root)
    if expected is not None and (":" not in expected or any(char.isspace() for char in expected)):
        raise SurfaceSyntaxError("RUO-N2-005 invalid expected Object ID assertion")
    end_line = start_index + len(parts)
    return ReasonObjectBindingNode(name, source_path, resource_root, mode, expected, SourceSpanNode(start_index + 1, 1, end_line, len(parts[-1]) + 1), tuple(clause_spans))


def _parse_reason_graph_binding(cursor: _Cursor) -> ReasonGraphBindingNode:
    index = cursor.index
    line = cursor.take()
    match = re.fullmatch(r'^reason_graph\s+([A-Za-z_][A-Za-z0-9_]*)\s+from\s+"([^"\\]+)"(?:\s+as\s+"([^"\\]+)")?;?$', line)
    if not match:
        raise SurfaceSyntaxError("RGO-LANG-001 invalid reason_graph binding")
    name, source_path, expected = match.groups()
    _validate_reason_object_path(source_path)
    if not source_path.endswith(".rgraph"):
        raise SurfaceSyntaxError("RGO-LANG-002 reason_graph source must use lowercase .rgraph")
    if expected is not None and (not expected.startswith("ruo:graph:") or any(char.isspace() for char in expected)):
        raise SurfaceSyntaxError("RGO-LANG-006 invalid expected graph ID assertion")
    return ReasonGraphBindingNode(name, source_path, expected, SourceSpanNode(index + 1, 1, index + 1, len(line) + 1))


def _reason_object_string(literal: str) -> str:
    if not (literal.startswith('"') and literal.endswith('"')):
        raise SurfaceSyntaxError("RUO-N2-003 reason_object clause requires a string")
    value = literal[1:-1]
    if "\\" in value:
        raise SurfaceSyntaxError("RUO-N2-006 escaped or platform-specific Object paths are prohibited")
    return value


def _validate_reason_object_path(value: str) -> None:
    pure = PurePosixPath(value)
    if (not value or pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts)
            or "://" in value or value.startswith(("~", "//")) or any(marker in value for marker in ("$", "`", "${", "$("))):
        raise SurfaceSyntaxError("RUO-N2-006 unsafe or non-relative Object path")


def _collect_simple_statement(cursor: _Cursor) -> str:
    # Collect potentially-multi-line simple statements by balancing
    # expression delimiters (parens/brackets/braces).
    start_index = cursor.index
    parts = [cursor.take()]
    first_location = _CURRENT_SOURCE_LINE.get()
    balance = _expression_delimiter_balance(parts[0])
    while balance > 0 and cursor.index < len(cursor.lines):
        next_line = cursor.take()
        parts.append(next_line)
        balance += _expression_delimiter_balance(next_line)
    if balance != 0:
        raise SurfaceSyntaxError("EX-201A-002 invalid struct literal syntax")
    # Determine the best source location for the combined expression.
    combined = " ".join(parts).strip()
    # Find the first logical line that contains the first token of the expression
    # so diagnostics/source locations point to the correct column.
    import re as _re
    m = _re.match(r"\S+", combined)
    if m:
        first_token = m.group(0)
    else:
        first_token = combined
    assigned = False
    for i in range(start_index, cursor.index):
        line_loc = cursor.locations[i]
        line_text = line_loc[2]
        if first_token in line_text:
            _CURRENT_SOURCE_LINE.set(line_loc)
            assigned = True
            break
    if not assigned:
        _CURRENT_SOURCE_LINE.set(first_location)
    return " ".join(parts)


def _expression_delimiter_balance(line: str) -> int:
    balance = 0
    for char in line:
        if char in "([{":
            balance += 1
        elif char in ")]}":
            balance -= 1
    return balance


def _parse_simple(line: str, *, context: str):
    declarations = {
        "concept": ConceptNode,
        "object": ObjectNode,
        "event": EventNode,
        "action": ActionNode,
        "attribute": AttributeNode,
        "constraint": ConstraintNode,
    }
    for keyword, node_type in declarations.items():
        match = re.fullmatch(rf"{keyword}\s+(\S+)", line)
        if match:
            return node_type(match.group(1))
    match = re.fullmatch(r"state\s+([A-Za-z_]\w*)", line)
    if match:
        return StateDeclarationNode(match.group(1))
    match = re.fullmatch(r"constraint\s+([A-Za-z_]\w*)\s*\{\s*(.+)\s*\}", line)
    if match:
        return ConstraintNode(match.group(1), match.group(2).strip())
    match = re.fullmatch(r"goal\s+(\S+)", line)
    if match:
        return (
            GoalNode(match.group(1))
            if context == "module"
            else GoalStatementNode(match.group(1))
        )
    match = re.fullmatch(
        r"import\s+([A-Za-z_][A-Za-z0-9_.]*)(?:\s+as\s+([A-Za-z_]\w*))?",
        line,
    )
    if match:
        return ImportNode(tuple(match.group(1).split(".")), match.group(2))
    match = re.fullmatch(
        r"([A-Za-z_]\w*)\s+(IsA|PartOf|Cause|Dependency|Constraint|Temporal|Spatial|Similar)\s+([A-Za-z_]\w*)",
        line,
    )
    if match:
        return RelationNode(match.group(1), RelationType(match.group(2)), match.group(3))
    match = re.fullmatch(r"let\s+([A-Za-z_]\w*)(?:\s*:\s*(.+?))?\s*=\s*(.+)", line)
    if match:
        return LetStatementNode(
            match.group(1),
            _expression(match.group(3)),
            _type_annotation(match.group(2)) if match.group(2) else None,
        )
    match = re.fullmatch(r"const\s+([A-Za-z_]\w*)(?:\s*:\s*(.+?))?\s*=\s*(.+)", line)
    if match:
        if context == "module":
            return ConstDeclarationNode(
                match.group(1),
                _expression(match.group(3)),
                _type_annotation(match.group(2)) if match.group(2) else None,
            )
        return ConstStatementNode(
            match.group(1),
            _expression(match.group(3)),
            _type_annotation(match.group(2)) if match.group(2) else None,
        )
    match = re.fullmatch(
        r"export\s+const\s+([A-Za-z_]\w*)(?:\s*:\s*(.+?))?\s*=\s*(.+)",
        line,
    )
    if match:
        if context != "module":
            raise SurfaceSyntaxError("ExportMustBeTopLevel")
        return ConstDeclarationNode(
            match.group(1),
            _expression(match.group(3)),
            _type_annotation(match.group(2)) if match.group(2) else None,
            Visibility.PUBLIC,
        )
    match = re.fullmatch(r"result\s*=\s*(.+)", line)
    if match:
        return ResultStatementNode(_expression(match.group(1)))
    match = re.fullmatch(r"return\s+(.+)", line)
    if match:
        return ReturnStatementNode(_expression(match.group(1)))
    match = re.fullmatch(r"(.+\.[A-Za-z_]\w*)\s*=\s*(.+)", line)
    if match:
        return FieldAssignmentStatementNode(
            _expression(match.group(1)),
            _expression(match.group(2)),
        )
    match = re.fullmatch(r"(.+\[.+\])\s*=\s*(.+)", line)
    if match:
        return IndexAssignmentStatementNode(
            _expression(match.group(1)),
            _expression(match.group(2)),
        )
    if line == "break":
        return BreakStatementNode()
    if line == "continue":
        return ContinueStatementNode()
    match = re.fullmatch(r"([A-Za-z_]\w*)\s*=\s*(.+)", line)
    if match:
        return AssignmentStatementNode(match.group(1), _expression(match.group(2)))
    match = re.fullmatch(r"requires?\s+([A-Za-z_]\w*)", line)
    if match:
        return RequireStatementNode(match.group(1))
    match = re.fullmatch(r"reach\s+([A-Za-z_]\w*)", line)
    if match:
        return ReachStatementNode(match.group(1))
    call = re.fullmatch(r"(.+\))", line)
    if call:
        return ExpressionStatementNode(_expression(call.group(1)))
    raise SurfaceSyntaxError(f"unsupported {context} statement: {line}")


def _parse_transition(cursor: _Cursor) -> TransitionNode:
    match = re.fullmatch(r"transition\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid transition declaration")
    name = match.group(1)
    from_state = ""
    to_state = ""
    body: list = []
    while cursor.index < len(cursor.lines):
        line = cursor.current()
        if line == "}":
            cursor.index += 1
            return TransitionNode(
                name, from_state, to_state, tuple(body)
            )
        if line.startswith("if "):
            body.append(_parse_if(cursor, context="transition"))
            continue
        if line.startswith("match "):
            body.append(_parse_match(cursor, context="transition"))
            continue
        cursor.index += 1
        state_match = re.fullmatch(r"([A-Za-z_]\w*)\s*->\s*([A-Za-z_]\w*)", line)
        if state_match:
            if from_state:
                raise SurfaceSyntaxError("transition has multiple state mappings")
            from_state, to_state = state_match.groups()
        else:
            body.append(_parse_simple(line, context="transition"))
    raise SurfaceSyntaxError("unterminated transition block")


def _parse_goal_declaration(cursor: _Cursor, *, context: str) -> GoalNode | GoalStatementNode:
    match = re.fullmatch(r"goal\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid goal declaration")
    metadata = _parse_metadata_block(cursor, owner="goal")
    if context != "module":
        return GoalStatementNode(match.group(1))
    return GoalNode(match.group(1), metadata)


def _parse_state_declaration(cursor: _Cursor) -> StateDeclarationNode:
    match = re.fullmatch(r"state\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid state declaration")
    return StateDeclarationNode(match.group(1), _parse_metadata_block(cursor, owner="state"))


def _parse_constraint_declaration(cursor: _Cursor) -> ConstraintNode:
    match = re.fullmatch(r"constraint\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid constraint declaration")
    expressions: list[str] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return ConstraintNode(match.group(1), " ".join(expressions).strip() or None)
        expressions.append(line)
    raise SurfaceSyntaxError("unterminated constraint declaration")


def _parse_metadata_block(cursor: _Cursor, *, owner: str) -> tuple[tuple[str, str], ...]:
    metadata: list[tuple[str, str]] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return tuple(metadata)
        match = re.fullmatch(r"([A-Za-z_]\w*)\s*:\s*(.+)", line)
        if not match:
            raise SurfaceSyntaxError(f"invalid {owner} metadata entry: {line}")
        metadata.append((match.group(1), match.group(2).strip()))
    raise SurfaceSyntaxError(f"unterminated {owner} declaration")


def _parse_reason_graph(cursor: _Cursor) -> ReasonGraphDeclarationNode:
    match = re.fullmatch(r"reason_graph\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid reason_graph declaration")
    states: list[StateDeclarationNode] = []
    transitions: list[ReasonGraphTransitionNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return ReasonGraphDeclarationNode(
                match.group(1), tuple(states), tuple(transitions)
            )
        state = re.fullmatch(r"state\s+([A-Za-z_]\w*)", line)
        if state:
            states.append(StateDeclarationNode(state.group(1)))
            continue
        transition = re.fullmatch(
            r"transition\s+([A-Za-z_]\w*)\s*->\s*([A-Za-z_]\w*)",
            line,
        )
        if transition:
            transitions.append(
                ReasonGraphTransitionNode(transition.group(1), transition.group(2))
            )
            continue
        raise SurfaceSyntaxError(f"invalid reason_graph member: {line}")
    raise SurfaceSyntaxError("unterminated reason_graph declaration")


def _parse_execution_plan(cursor: _Cursor) -> ExecutionPlanDeclarationNode:
    match = re.fullmatch(r"execution_plan\s+([A-Za-z_]\w*)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid execution_plan declaration")
    steps: list[PlanStepNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return ExecutionPlanDeclarationNode(match.group(1), tuple(steps))
        step = re.fullmatch(r"step\s+([A-Za-z_]\w*)\s*->\s*([A-Za-z_]\w*)", line)
        if not step:
            raise SurfaceSyntaxError(f"invalid execution_plan step: {line}")
        steps.append(PlanStepNode(step.group(1), step.group(2)))
    raise SurfaceSyntaxError("unterminated execution_plan declaration")


def _parse_calculation(cursor: _Cursor) -> CalculationNode:
    match = re.fullmatch(
        r"(?:(pub|export)\s+)?calculation\s+([A-Za-z_]\w*)"
        r"(?:\s+goal:([A-Za-z_]\w*))?"
        r"(?:\s*->\s*(.+?))?\s*\{",
        cursor.take(),
    )
    if not match:
        raise SurfaceSyntaxError("invalid calculation declaration")
    body = _parse_body(cursor, context="calculation")
    visibility = Visibility.PUBLIC if match.group(1) else Visibility.PRIVATE
    return CalculationNode(
        match.group(2),
        match.group(3),
        tuple(body),
        visibility,
        _type_annotation(match.group(4)) if match.group(4) else None,
    )


def _parse_struct(cursor: _Cursor) -> StructDeclarationNode:
    declaration = cursor.take()
    compact = re.fullmatch(
        r"(?:(export)\s+)?struct\s+([A-Za-z_]\w*)\s*\{(.*)\}",
        declaration,
    )
    if compact:
        return StructDeclarationNode(
            compact.group(2),
            _parse_compact_struct_fields(compact.group(3)),
            Visibility.PUBLIC if compact.group(1) else Visibility.PRIVATE,
        )
    match = re.fullmatch(
        r"(?:(export)\s+)?struct\s+([A-Za-z_]\w*)\s*\{",
        declaration,
    )
    if not match:
        raise SurfaceSyntaxError("PARSE-001 invalid struct declaration")
    fields: list[StructFieldNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return StructDeclarationNode(
                match.group(2),
                tuple(fields),
                Visibility.PUBLIC if match.group(1) else Visibility.PRIVATE,
            )
        field = re.fullmatch(r"([A-Za-z_]\w*)\s*:\s*(.+)", line)
        if not field:
            raise SurfaceSyntaxError("TV-4 FieldTypeRequired")
        fields.append(StructFieldNode(field.group(1), _type_annotation(field.group(2))))
    raise SurfaceSyntaxError("unterminated struct declaration")


def _parse_compact_struct_fields(body: str) -> tuple[StructFieldNode, ...]:
    text = body.strip()
    if not text:
        return ()

    markers: list[tuple[int, int, str]] = []
    depth = 0
    index = 0
    while index < len(text):
        char = text[index]
        if char in "([<":
            depth += 1
        elif char in ")]>":
            depth -= 1
            if depth < 0:
                raise SurfaceSyntaxError(
                    "PARSE-001 invalid compact struct field type"
                )
        elif depth == 0 and (char.isalpha() or char == "_"):
            field = re.match(r"([A-Za-z_]\w*)\s*:(?!:)", text[index:])
            if field:
                markers.append(
                    (index, index + field.end(), field.group(1))
                )
                index += field.end()
                continue
        index += 1

    if depth != 0 or not markers or text[:markers[0][0]].strip(" ,;"):
        raise SurfaceSyntaxError("PARSE-001 invalid compact struct declaration")

    fields: list[StructFieldNode] = []
    for marker_index, (_, value_start, name) in enumerate(markers):
        value_end = (
            markers[marker_index + 1][0]
            if marker_index + 1 < len(markers)
            else len(text)
        )
        field_type = text[value_start:value_end].strip().rstrip(",;").strip()
        if not field_type:
            raise SurfaceSyntaxError(
                f"PARSE-001 compact struct field requires a type: {name}"
            )
        fields.append(StructFieldNode(name, _type_annotation(field_type)))
    return tuple(fields)


def _parse_enum(cursor: _Cursor) -> EnumDeclarationNode:
    match = re.fullmatch(
        r"(?:(export)\s+)?enum\s+([A-Za-z_]\w*)\s*\{",
        cursor.take(),
    )
    if not match:
        raise SurfaceSyntaxError("invalid enum declaration")
    values: list[EnumValueNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return EnumDeclarationNode(
                match.group(2),
                tuple(values),
                Visibility.PUBLIC if match.group(1) else Visibility.PRIVATE,
            )
        value = re.fullmatch(r"([A-Za-z_]\w*)", line)
        if not value:
            raise SurfaceSyntaxError("invalid enum value")
        values.append(EnumValueNode(value.group(1)))
    raise SurfaceSyntaxError("unterminated enum declaration")


def _parse_function(cursor: _Cursor) -> FunctionDeclarationNode:
    signature = _collect_function_signature(cursor)
    match = re.fullmatch(
        r"(?:(pub|export)\s+)?fn\s+([A-Za-z_]\w*)\s*\(([^)]*)\)"
        r"(?:\s*(?:->|:)\s*(.+?))?\s*\{",
        signature,
    )
    if not match:
        raise SurfaceSyntaxError("invalid function declaration")
    parameters = _parameters(match.group(3))
    body = _parse_body(cursor, context="function")
    visibility = Visibility.PUBLIC if match.group(1) else Visibility.PRIVATE
    return FunctionDeclarationNode(
        match.group(2),
        parameters,
        tuple(body),
        visibility,
        _type_annotation(match.group(4)) if match.group(4) else None,
    )


def _collect_function_signature(cursor: _Cursor) -> str:
    parts = [cursor.take()]
    balance = _parenthesis_balance(parts[0])
    while balance > 0 and cursor.index < len(cursor.lines):
        next_line = cursor.take()
        parts.append(next_line)
        balance += _parenthesis_balance(next_line)
    if balance != 0:
        raise SurfaceSyntaxError("invalid function declaration")
    return " ".join(parts)


def _parenthesis_balance(line: str) -> int:
    return line.count("(") - line.count(")")


def _parse_for(cursor: _Cursor, *, context: str) -> ForStatementNode:
    match = re.fullmatch(
        r"for\s+([A-Za-z_]\w*)\s+in\s+(.+)\s*\{",
        cursor.take(),
    )
    if not match:
        raise SurfaceSyntaxError("invalid for statement")
    return ForStatementNode(
        match.group(1),
        _expression(match.group(2)),
        tuple(_parse_body(cursor, context=context)),
    )


def _parse_while(cursor: _Cursor, *, context: str) -> WhileStatementNode:
    match = re.fullmatch(r"while\s+(.+)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid while statement")
    return WhileStatementNode(
        _expression(match.group(1)),
        tuple(_parse_body(cursor, context=context)),
    )


def _parse_loop(cursor: _Cursor, *, context: str) -> LoopStatementNode:
    cursor.take()
    return LoopStatementNode(tuple(_parse_body(cursor, context=context)))


def _parse_if(cursor: _Cursor, *, context: str) -> IfStatementNode:
    match = re.fullmatch(r"if\s+(.+)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid if statement")
    body = tuple(_parse_body(cursor, context=context))
    elif_branches: list[ElseIfStatementNode] = []
    else_branch = None
    while cursor.index < len(cursor.lines) and cursor.current().startswith("elif "):
        branch = re.fullmatch(r"elif\s+(.+)\s*\{", cursor.take())
        if not branch:
            raise SurfaceSyntaxError("invalid elif statement")
        elif_branches.append(
            ElseIfStatementNode(
                _expression(branch.group(1)),
                tuple(_parse_body(cursor, context=context)),
            )
        )
    if cursor.index < len(cursor.lines) and cursor.current() == "else {":
        cursor.index += 1
        else_branch = ElseStatementNode(tuple(_parse_body(cursor, context=context)))
    return IfStatementNode(
        _expression(match.group(1)),
        body,
        tuple(elif_branches),
        else_branch,
    )


def _parse_match(cursor: _Cursor, *, context: str) -> MatchStatementNode:
    match = re.fullmatch(r"match\s+(.+)\s*\{", cursor.take())
    if not match:
        raise SurfaceSyntaxError("invalid match statement")
    arms: list[MatchArmNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return MatchStatementNode(_expression(match.group(1)), tuple(arms))
        line = _collect_match_arm(cursor, line)
        guarded_arm = re.fullmatch(r"(.+?)\s+when\s+(.+?)\s*=>\s*(.+)", line)
        arm = guarded_arm or re.fullmatch(r"(.+?)\s*=>\s*(.+)", line)
        if not arm:
            raise SurfaceSyntaxError(f"invalid match arm: {line}")
        pattern_source = arm.group(1)
        guard = _expression(arm.group(2)) if guarded_arm else None
        body_source = arm.group(3) if guarded_arm else arm.group(2)
        arm_body = (
            tuple(_parse_body(cursor, context=context))
            if body_source.strip() == "{"
            else (_parse_simple(body_source.strip(), context=context),)
        )
        arms.append(
            MatchArmNode(
                _pattern(pattern_source),
                arm_body,
                guard,
            )
        )
    raise SurfaceSyntaxError("unterminated match block")


def _collect_match_arm(cursor: _Cursor, line: str) -> str:
    collected = _collect_struct_pattern_arm(cursor, line)
    if "=>" in collected:
        return collected
    if cursor.index < len(cursor.lines) and cursor.current().startswith("when "):
        parts = [collected, cursor.take()]
        if cursor.index < len(cursor.lines) and cursor.current().startswith("=>"):
            parts.append(cursor.take())
            return " ".join(parts)
        raise SurfaceSyntaxError(f"invalid match arm: {' '.join(parts)}")
    if cursor.index < len(cursor.lines) and cursor.current().startswith("=>"):
        return " ".join([collected, cursor.take()])
    return collected


def _collect_struct_pattern_arm(cursor: _Cursor, line: str) -> str:
    if "=>" in line or not re.fullmatch(
        r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*\s*\{", line
    ):
        return line
    parts = [line]
    depth = _brace_delta(line)
    if depth > MAX_PATTERN_DEPTH + 1:
        raise SurfaceSyntaxError("NP-010 nested pattern depth exceeded")
    while cursor.index < len(cursor.lines):
        next_line = cursor.take()
        parts.append(next_line)
        depth += _pattern_brace_delta(next_line)
        if depth > MAX_PATTERN_DEPTH + 1:
            raise SurfaceSyntaxError("NP-010 nested pattern depth exceeded")
        if depth <= 0:
            return _complete_struct_pattern_arm(cursor, parts)
    raise SurfaceSyntaxError("SP-002 NP-003 missing closing brace")


def _complete_struct_pattern_arm(cursor: _Cursor, parts: list[str]) -> str:
    collected = " ".join(parts)
    if "=>" in parts[-1]:
        return collected
    if cursor.index < len(cursor.lines) and cursor.current().startswith("when "):
        parts.append(cursor.take())
        if cursor.index < len(cursor.lines) and cursor.current().startswith("=>"):
            parts.append(cursor.take())
            return " ".join(parts)
        raise SurfaceSyntaxError(f"invalid match arm: {' '.join(parts)}")
    if cursor.index < len(cursor.lines) and cursor.current().startswith("=>"):
        parts.append(cursor.take())
        return " ".join(parts)
    raise SurfaceSyntaxError("SP-002 NP-003 missing closing brace")


def _brace_delta(line: str) -> int:
    depth = 0
    in_string: str | None = None
    escaped = False
    for char in line:
        if in_string is not None:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == in_string:
                in_string = None
            continue
        if char in {'"', "'"}:
            in_string = char
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
    return depth


def _pattern_brace_delta(line: str) -> int:
    return _brace_delta(line.split("=>", 1)[0])


def _expression(source: str):
    try:
        stripped = source.strip()
        expression = parse_expression(stripped, allow_tuple_access=True)
        normalized = _normalize_runtime_expression(expression.expression)
        current = _CURRENT_SOURCE_LINE.get()
        if current is not None:
            line, base_column, text = current
            offset = text.find(stripped)
            location = {
                "line": line,
                "column": base_column + max(offset, 0),
            }
            _attach_source_location(normalized, location)
        return ExpressionNode(normalized)
    except ExpressionSyntaxError as error:
        raise SurfaceSyntaxError(str(error)) from error


def _attach_source_location(value, location: dict[str, int]) -> None:
    if not is_dataclass(value):
        return
    object.__setattr__(value, "_source_location", dict(location))
    for descriptor in fields(value):
        child = getattr(value, descriptor.name)
        if isinstance(child, tuple):
            for item in child:
                _attach_source_location(item, location)
        else:
            _attach_source_location(child, location)


def _normalize_runtime_expression(value):
    if isinstance(value, CallExpressionNode):
        callee = _normalize_runtime_expression(value.callee)
        arguments = tuple(
            _normalize_runtime_expression(item) for item in value.arguments
        )
        if isinstance(callee, IdentifierNode):
            kind = {
                "input": RuntimeCallKind.INPUT,
                "print": RuntimeCallKind.PRINT,
            }.get(callee.name)
            if kind is not None:
                return RuntimeCallExpressionNode(
                    RuntimeNamespaceNode(), callee.name, kind, arguments
                )
        if (
            isinstance(callee, MemberAccessNode)
            and isinstance(callee.object, RuntimeNamespaceNode)
        ):
            kind = {
                "input": RuntimeCallKind.INPUT,
                "print": RuntimeCallKind.PRINT,
                "search": RuntimeCallKind.SEARCH,
                "simulate": RuntimeCallKind.SIMULATION,
                "predict": RuntimeCallKind.PREDICTION,
                "plan": RuntimeCallKind.PLANNING,
            }.get(callee.member)
            if kind is None:
                raise SurfaceSyntaxError("UnknownRuntimeMethod")
            return RuntimeCallExpressionNode(
                callee.object, callee.member, kind, arguments
            )
        return CallExpressionNode(callee, arguments)
    if isinstance(value, MemberAccessNode):
        normalized_object = _normalize_runtime_expression(value.object)
        if (
            isinstance(normalized_object, IdentifierNode)
            and normalized_object.name == "runtime"
        ):
            normalized_object = RuntimeNamespaceNode()
        return MemberAccessNode(normalized_object, value.member)
    if isinstance(value, ParenthesizedExpressionNode):
        return ParenthesizedExpressionNode(
            _normalize_runtime_expression(value.expression)
        )
    if isinstance(value, UnaryExpressionNode):
        return UnaryExpressionNode(
            value.operator, _normalize_runtime_expression(value.operand)
        )
    if isinstance(value, BinaryExpressionNode):
        return BinaryExpressionNode(
            _normalize_runtime_expression(value.left),
            value.operator,
            _normalize_runtime_expression(value.right),
        )
    if isinstance(value, ComparisonExpressionNode):
        return ComparisonExpressionNode(
            _normalize_runtime_expression(value.left),
            value.operator,
            _normalize_runtime_expression(value.right),
        )
    if isinstance(value, LogicalExpressionNode):
        return LogicalExpressionNode(
            _normalize_runtime_expression(value.left),
            value.operator,
            _normalize_runtime_expression(value.right),
        )
    if isinstance(value, SomeExpressionNode):
        return SomeExpressionNode(_normalize_runtime_expression(value.value))
    if isinstance(value, IndexAccessNode):
        return IndexAccessNode(
            _normalize_runtime_expression(value.collection),
            _normalize_runtime_expression(value.index),
        )
    if isinstance(value, StructLiteralNode):
        return StructLiteralNode(
            value.type_name,
            tuple(
                StructLiteralFieldNode(
                    field.name,
                    ExpressionNode(
                        _normalize_runtime_expression(field.expression.expression)
                    ),
                )
                for field in value.fields
            ),
        )
    if isinstance(value, (ArrayLiteralNode, TupleLiteralNode, SetLiteralNode)):
        return type(value)(
            tuple(
                ExpressionNode(_normalize_runtime_expression(item.expression))
                for item in value.elements
            )
        )
    if isinstance(value, MapLiteralNode):
        return MapLiteralNode(
            tuple(
                MapEntryNode(
                    ExpressionNode(_normalize_runtime_expression(entry.key.expression)),
                    ExpressionNode(
                        _normalize_runtime_expression(entry.value.expression)
                    ),
                )
                for entry in value.entries
            )
        )
    return value


def _is_struct_literal_statement(line: str) -> bool:
    return bool(
        re.fullmatch(
            r"(?:let|const)\s+[A-Za-z_]\w*(?:\s*:\s*[A-Za-z_]\w*)?\s*=\s*[A-Za-z_]\w*\s*\{",
            line,
        )
        or re.fullmatch(r"(?:return|result\s*=)\s*[A-Za-z_]\w*\s*\{", line)
    )


def _is_collection_literal_statement(line: str) -> bool:
    return bool(
        re.fullmatch(r"(?:let|const)\s+[A-Za-z_]\w*(?:\s*:\s*.+?)?\s*=\s*(?:set|map)\s*\{", line)
        or re.fullmatch(r"(?:return|result\s*=)\s*(?:set|map)\s*\{", line)
    )


def _parse_collection_literal_statement(cursor: _Cursor):
    line = cursor.take()
    binding = re.fullmatch(
        r"(let|const)\s+([A-Za-z_]\w*)(?:\s*:\s*(.+?))?\s*=\s*(set|map)\s*\{",
        line,
    )
    if binding:
        literal = _parse_collection_literal_body(cursor, binding.group(4))
        type_annotation = (
            _type_annotation(binding.group(3)) if binding.group(3) else None
        )
        if binding.group(1) == "let":
            return LetStatementNode(binding.group(2), literal, type_annotation)
        return ConstStatementNode(binding.group(2), literal, type_annotation)
    terminal = re.fullmatch(r"(return|result\s*=)\s*(set|map)\s*\{", line)
    if terminal:
        literal = _parse_collection_literal_body(cursor, terminal.group(2))
        return (
            ReturnStatementNode(literal)
            if terminal.group(1) == "return"
            else ResultStatementNode(literal)
        )
    raise SurfaceSyntaxError(f"invalid collection literal statement: {line}")


def _parse_collection_literal_body(cursor: _Cursor, kind: str) -> ExpressionNode:
    if kind == "set":
        elements = []
        while cursor.index < len(cursor.lines):
            line = cursor.take()
            if line == "}":
                return ExpressionNode(SetLiteralNode(tuple(elements)))
            elements.append(_expression(line.rstrip(",")))
        raise SurfaceSyntaxError("unterminated set literal")
    entries = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return ExpressionNode(MapLiteralNode(tuple(entries)))
        entry = re.fullmatch(r"(.+?)\s*:\s*(.+?),?", line)
        if not entry:
            raise SurfaceSyntaxError(f"invalid map entry: {line}")
        nested = re.fullmatch(r"([A-Za-z_]\w*)\s*\{", entry.group(2).strip())
        value = (
            _parse_struct_literal_body(cursor, nested.group(1))
            if nested
            else _expression(entry.group(2))
        )
        entries.append(MapEntryNode(_expression(entry.group(1)), value))
    raise SurfaceSyntaxError("unterminated map literal")


def _parse_struct_literal_statement(cursor: _Cursor):
    line = cursor.take()
    binding = re.fullmatch(
        r"(let|const)\s+([A-Za-z_]\w*)(?:\s*:\s*([A-Za-z_]\w*))?\s*=\s*([A-Za-z_]\w*)\s*\{",
        line,
    )
    if binding:
        literal = _parse_struct_literal_body(cursor, binding.group(4))
        type_annotation = (
            _type_annotation(binding.group(3)) if binding.group(3) else None
        )
        if binding.group(1) == "let":
            return LetStatementNode(binding.group(2), literal, type_annotation)
        return ConstStatementNode(binding.group(2), literal, type_annotation)
    terminal = re.fullmatch(r"(return|result\s*=)\s*([A-Za-z_]\w*)\s*\{", line)
    if terminal:
        literal = _parse_struct_literal_body(cursor, terminal.group(2))
        return (
            ReturnStatementNode(literal)
            if terminal.group(1) == "return"
            else ResultStatementNode(literal)
        )
    raise SurfaceSyntaxError(f"invalid struct literal statement: {line}")


def _parse_struct_literal_body(cursor: _Cursor, type_name: str) -> ExpressionNode:
    fields: list[StructLiteralFieldNode] = []
    while cursor.index < len(cursor.lines):
        line = cursor.take()
        if line == "}":
            return ExpressionNode(StructLiteralNode(type_name, tuple(fields)))
        field = re.fullmatch(r"([A-Za-z_]\w*)\s*:\s*(.+)", line)
        if not field:
            raise SurfaceSyntaxError(f"invalid struct literal field: {line}")
        nested = re.fullmatch(r"([A-Za-z_]\w*)\s*\{", field.group(2).strip())
        expression = (
            _parse_struct_literal_body(cursor, nested.group(1))
            if nested
            else _expression(field.group(2))
        )
        fields.append(StructLiteralFieldNode(field.group(1), expression))
    raise SurfaceSyntaxError("unterminated struct literal")


def _pattern(source: str):
    try:
        return parse_pattern(source.strip())
    except ExpressionSyntaxError as error:
        raise SurfaceSyntaxError(str(error)) from error


def _type_annotation(source: str):
    source = source.strip()
    if source.startswith("[") and source.endswith("]"):
        return ArrayTypeNode(_type_annotation(source[1:-1]))
    optional_match = re.fullmatch(r"optional\s*<\s*(.+)\s*>", source)
    if optional_match:
        return OptionalTypeNode(_type_annotation(optional_match.group(1)))
    if source.startswith("(") and source.endswith(")"):
        inner = source[1:-1].strip()
        if not inner:
            raise SurfaceSyntaxError("TYPE-V001 tuple type requires elements")
        return TupleTypeNode(tuple(_type_annotation(item.strip()) for item in inner.split(",")))
    set_match = re.fullmatch(r"set\s*<\s*(.+)\s*>", source)
    if set_match:
        return SetTypeNode(_type_annotation(set_match.group(1)))
    map_match = re.fullmatch(r"map\s*<\s*(.+)\s*,\s*(.+)\s*>", source)
    if map_match:
        return MapTypeNode(
            _type_annotation(map_match.group(1)),
            _type_annotation(map_match.group(2)),
        )
    primitive_aliases = {
        "int": PrimitiveKind.INT,
        "float": PrimitiveKind.FLOAT,
        "bool": PrimitiveKind.BOOL,
        "string": PrimitiveKind.STRING,
        "null": PrimitiveKind.NULL,
    }
    if source in primitive_aliases:
        return PrimitiveTypeNode(primitive_aliases[source])
    try:
        return PrimitiveTypeNode(PrimitiveKind(source))
    except ValueError:
        pass
    try:
        return StateTypeNode(StateKind(source))
    except ValueError:
        return NamedTypeNode(source)


def _parameters(source: str) -> tuple[dict[str, object], ...]:
    text = source.strip()
    if not text:
        return ()
    parameters: list[object] = []
    seen: set[str] = set()
    for part in text.split(","):
        parameter = part.strip()
        match = re.fullmatch(r"([A-Za-z_]\w*)\s*:\s*(.+)", parameter)
        if not match:
            if re.fullmatch(r"[A-Za-z_]\w*", parameter):
                if parameter in seen:
                    raise SurfaceSyntaxError(f"FN-006 duplicate parameter: {parameter}")
                seen.add(parameter)
                parameters.append(parameter)
                continue
            raise SurfaceSyntaxError(f"FN-002 parameter type required: {parameter}")
        name = match.group(1)
        if name in seen:
            raise SurfaceSyntaxError(f"FN-006 duplicate parameter: {name}")
        seen.add(name)
        parameters.append({"name": name, "type": _type_annotation(match.group(2))})
    return tuple(parameters)
