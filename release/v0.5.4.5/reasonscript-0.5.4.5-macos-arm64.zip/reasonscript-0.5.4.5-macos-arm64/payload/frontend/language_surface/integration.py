"""Projection from Surface AST to the validated semantic AST/compiler."""

from __future__ import annotations

import hashlib
from typing import Any

from frontend import ast as semantic
from frontend.compiler import compile as compile_semantic
from frontend.tensor.integration import (
    public_registry as tensor_public_registry,
)
from frontend.tensor.integration import (
    tensor_execution_plan,
    tensor_operations,
)
from frontend.vision.integration import (
    public_registry as vision_public_registry,
)
from frontend.vision.integration import (
    vision_execution_plan,
    vision_operations,
)

from .namespace import resolve_program
from .nodes import (
    ArrayLiteralNode,
    AssignmentStatementNode,
    BinaryExpressionNode,
    BinaryOperator,
    BooleanLiteralNode,
    BreakStatementNode,
    CalculationNode,
    CallExpressionNode,
    ComparisonExpressionNode,
    ComparisonOperator,
    ConstDeclarationNode,
    ConstraintNode,
    ConstStatementNode,
    ContinueStatementNode,
    DefaultPatternNode,
    EnumDeclarationNode,
    EnumValuePatternNode,
    ExecutionPlanDeclarationNode,
    ExpressionNode,
    ExpressionStatementNode,
    FieldAssignmentStatementNode,
    FloatLiteralNode,
    ForStatementNode,
    FunctionDeclarationNode,
    GoalNode,
    GoalStatementNode,
    IdentifierNode,
    IdentifierPatternNode,
    IfStatementNode,
    ImportNode,
    IndexAccessNode,
    IndexAssignmentStatementNode,
    IntegerLiteralNode,
    LetStatementNode,
    LiteralPatternNode,
    LogicalExpressionNode,
    LogicalOperator,
    LoopStatementNode,
    MapLiteralNode,
    MatchStatementNode,
    MemberAccessNode,
    ModuleNode,
    NamedTypeNode,
    NoneLiteralNode,
    OptionalPatternNode,
    OptionalValuePatternNode,
    OrPatternNode,
    ParenthesizedExpressionNode,
    PatternNode,
    ProgramNode,
    QualifiedIdentifierNode,
    QualifiedPatternNode,
    RangePatternNode,
    ReachStatementNode,
    ReasonGraphDeclarationNode,
    ReasonObjectBindingNode,
    RelationNode,
    RequireStatementNode,
    ResultStatementNode,
    ReturnStatementNode,
    RuntimeCallExpressionNode,
    RuntimeCallKind,
    RuntimeNamespaceNode,
    SetLiteralNode,
    SomeExpressionNode,
    StateDeclarationNode,
    StringLiteralNode,
    StructBindingPatternNode,
    StructDeclarationNode,
    StructLiteralNode,
    StructPatternNode,
    TransitionNode,
    TupleLiteralNode,
    UnaryExpressionNode,
    UnaryOperator,
    Visibility,
    WhileStatementNode,
    WildcardPatternNode,
    to_json_value,
)
from .pattern_decision import PatternDecisionBuilder, pattern_decision_to_json
from .pattern_evaluator import PatternEvaluator, RuntimeEnumValue, RuntimeStructValue
from .semantic_patterns import StructPatternSemanticError, resolve_struct_pattern
from .validation import SurfaceValidationError, validate


def project_program(program: ProgramNode) -> tuple[semantic.ModuleNode, ...]:
    resolved_program, _ = resolve_program(program)
    validate(resolved_program)
    package = resolved_program.package.name if resolved_program.package else None
    return tuple(
        project_module(module, package=package)
        for module in resolved_program.modules
    )


def project_module(module: ModuleNode, *, package: str | None = None) -> semantic.ModuleNode:
    namespace = f"{package}.{module.name}" if package else module.name
    calculation_order = _topological_calculations(module)
    calculation_dependencies = _calculation_dependencies(module)
    function_call_dependencies = _function_call_dependencies(module)
    calculation_result_target = (
        f"{calculation_order[-1].name}.state.result"
        if calculation_order
        else None
    )
    declarations: list[Any] = []
    imports: list[str] = []
    surface_goals = [node for node in module.body if isinstance(node, GoalNode)]
    goal_target = surface_goals[0].name if surface_goals else f"{module.name}Result"
    module_tensor_operations = tensor_operations(module)
    module_vision_operations = vision_operations(module)
    reason_object_bindings = _reason_object_bindings(module, namespace)
    reason_object_operations = _reason_object_operations(module)
    declarations.append(
        semantic.GoalNode(
            f"{namespace}-goal",
            "reach_state",
            calculation_result_target or goal_target,
        )
    )
    declarations.append(
        semantic.StateNode(
            f"{namespace}-state",
            f"{module.name}Start",
            "language_surface",
            {
                "package": package,
                "module": module.name,
                "namespace": namespace,
                "visibility": module.visibility.value,
                "declarations": [
                    type(node).__name__
                    for node in module.body
                    if not isinstance(node, ImportNode)
                ],
                "semantic_functions": _semantic_function_nodes(module, namespace),
            },
        )
    )
    transition_index = 0
    calculations_projected = False
    for node in module.body:
        if isinstance(node, ImportNode):
            imports.append(".".join(node.path))
        elif isinstance(node, ConstraintNode):
            declarations.append(
                semantic.ConstraintNode(
                    f"{namespace}-constraint-{node.name}",
                    node.name,
                    "predicate",
                    node.name,
                )
            )
        elif isinstance(node, RelationNode):
            transition_index += 1
            declarations.append(
                semantic.TransitionNode(
                    f"{namespace}-relation-{transition_index}",
                    f"{namespace}-relation-{transition_index}",
                    node.source,
                    node.relation.value,
                    node.target,
                )
            )
        elif isinstance(node, TransitionNode):
            transition_index += 1
            requirements = [
                statement.constraint
                for statement in node.body
                if isinstance(statement, RequireStatementNode)
            ]
            goal_refs = [
                statement.goal
                for statement in node.body
                if isinstance(statement, GoalStatementNode)
            ]
            reaches = [
                statement.goal
                for statement in node.body
                if isinstance(statement, ReachStatementNode)
            ]
            declarations.append(
                semantic.TransitionNode(
                    f"{namespace}-transition-{transition_index}",
                    node.name,
                    node.from_state,
                    "Transition",
                    reaches[-1] if reaches else node.to_state,
                    guard=" && ".join(requirements) or None,
                    effect={
                        "goals": goal_refs,
                        "body": [to_json_value(item) for item in node.body],
                    },
                )
            )
        elif isinstance(node, CalculationNode):
            if not calculations_projected:
                transition_index = _project_calculations(
                    declarations,
                    calculation_order,
                    namespace=namespace,
                    module=module,
                    start_index=transition_index,
                )
                calculations_projected = True
    return semantic.ModuleNode(
        node_id=namespace,
        imports=tuple(imports),
        declarations=tuple(declarations),
        metadata=(
            semantic.MetadataNode(
                f"{namespace}-surface-version",
                "language_surface",
                "reasonscript-language-surface/0.1",
            ),
            semantic.MetadataNode(
                f"{namespace}-namespace",
                "namespace",
                namespace,
            ),
            semantic.MetadataNode(
                f"{namespace}-package",
                "package",
                package,
            ),
            semantic.MetadataNode(
                f"{namespace}-module",
                "module",
                module.name,
            ),
            semantic.MetadataNode(
                f"{namespace}-exports",
                "exports",
                _exports(module),
            ),
            semantic.MetadataNode(
                f"{namespace}-import-resolution",
                "import_resolution",
                [
                    to_json_value(node.resolution)
                    for node in module.body
                    if isinstance(node, ImportNode) and node.resolution is not None
                ],
            ),
            semantic.MetadataNode(
                f"{namespace}-functions",
                "function_declarations",
                [
                    to_json_value(node)
                    for node in module.body
                    if isinstance(node, FunctionDeclarationNode)
                ],
            ),
            semantic.MetadataNode(
                f"{namespace}-semantic-functions",
                "semantic_functions",
                _semantic_function_nodes(module, namespace),
            ),
            semantic.MetadataNode(
                f"{namespace}-function-symbols",
                "function_symbols",
                _function_symbols(module, namespace),
            ),
            semantic.MetadataNode(
                f"{namespace}-function-ir",
                "function_ir",
                _function_ir_nodes(module, namespace),
            ),
            semantic.MetadataNode(
                f"{namespace}-function-calls",
                "function_calls",
                _function_call_ir_nodes(module, namespace),
            ),
            semantic.MetadataNode(
                f"{namespace}-composite-types",
                "composite_declarations",
                [
                    to_json_value(node)
                    for node in module.body
                    if isinstance(node, (StructDeclarationNode, EnumDeclarationNode))
                ],
            ),
            semantic.MetadataNode(
                f"{namespace}-enum-symbols",
                "enum_symbols",
                _enum_symbols(module),
            ),
            semantic.MetadataNode(
                f"{namespace}-consts",
                "const_declarations",
                [
                    to_json_value(node)
                    for node in module.body
                    if isinstance(node, ConstDeclarationNode)
                ],
            ),
            semantic.MetadataNode(
                f"{namespace}-runtime-calls",
                "runtime_calls",
                _runtime_calls(module),
            ),
            semantic.MetadataNode(
                f"{namespace}-runtime-operations",
                "runtime_operations",
                _runtime_operations(module),
            ),
            *(
                (semantic.MetadataNode(f"{namespace}-reason-object-bindings", "reason_object_bindings", reason_object_bindings),)
                if reason_object_bindings else ()
            ),
            *(
                (semantic.MetadataNode(f"{namespace}-reason-object-operations", "reason_object_operations", reason_object_operations),)
                if reason_object_operations else ()
            ),
            *(
                (
                    semantic.MetadataNode(
                        f"{namespace}-tensor-registry",
                        "tensor_function_registry",
                        list(tensor_public_registry()),
                    ),
                    semantic.MetadataNode(
                        f"{namespace}-tensor-operations",
                        "tensor_operations",
                        module_tensor_operations,
                    ),
                    semantic.MetadataNode(
                        f"{namespace}-tensor-execution-plan",
                        "tensor_execution_plan",
                        tensor_execution_plan(module_tensor_operations),
                    ),
                )
                if module_tensor_operations
                else ()
            ),
            *(
                (
                    semantic.MetadataNode(
                        f"{namespace}-vision-registry",
                        "vision_function_registry",
                        list(vision_public_registry()),
                    ),
                    semantic.MetadataNode(
                        f"{namespace}-vision-operations",
                        "vision_operations",
                        module_vision_operations,
                    ),
                    semantic.MetadataNode(
                        f"{namespace}-vision-execution-plan",
                        "vision_execution_plan",
                        vision_execution_plan(module_vision_operations),
                    ),
                )
                if module_vision_operations
                else ()
            ),
            semantic.MetadataNode(
                f"{namespace}-reasoning-types",
                "reasoning_types",
                _reasoning_types(module),
            ),
            semantic.MetadataNode(
                f"{namespace}-reasoning-declarations",
                "reasoning_declarations",
                _reasoning_declarations(module),
            ),
            semantic.MetadataNode(
                f"{namespace}-calculation-order",
                "calculation_order",
                [node.name for node in calculation_order],
            ),
            semantic.MetadataNode(
                f"{namespace}-calculation-dependencies",
                "calculation_dependencies",
                [
                    {"source": source, "target": target}
                    for target in sorted(calculation_dependencies)
                    for source in sorted(calculation_dependencies[target])
                ]
                + [
                    {"source": source, "target": target}
                    for target in sorted(function_call_dependencies)
                    for source in sorted(function_call_dependencies[target])
                ],
            ),
        ),
    )


def _project_calculations(
    declarations: list[Any],
    calculations: tuple[CalculationNode, ...],
    *,
    namespace: str,
    module: ModuleNode,
    start_index: int,
) -> int:
    transition_index = start_index
    current = f"{module.name}Start"
    calculation_names = {node.name for node in calculations}
    functions = {
        node.name: node for node in module.body if isinstance(node, FunctionDeclarationNode)
    }
    emitted_function_returns: set[str] = set()
    for node in calculations:
        local_names: set[str] = set()
        current_sources = [current]
        for index, statement in enumerate(node.body, 1):
            identifier, statement_data, relation = _statement_projection(
                statement, index
            )
            expression = _statement_expression(statement)
            for call_index, function_name in enumerate(
                _expression_function_calls(expression),
                1,
            ):
                function = functions.get(function_name)
                if function is None or function_name in emitted_function_returns:
                    continue
                if len(current_sources) > 1:
                    merge_target = (
                        f"{node.name}.state.call.{index}.{call_index}.{function_name}"
                    )
                    for source_index, source in enumerate(current_sources, 1):
                        transition_index += 1
                        declarations.append(
                            semantic.TransitionNode(
                                f"{namespace}-function-{transition_index}",
                                (
                                    f"{node.name}-{index}-call-{call_index}-"
                                    f"merge-{source_index}"
                                ),
                                source,
                                "FunctionCallMergeTransition",
                                merge_target,
                                effect={
                                    "calculation": node.name,
                                    "function": f"{namespace}.{function_name}",
                                    "source_return": source,
                                },
                            )
                        )
                    current_sources = [merge_target]
                return_paths = _function_return_paths(function, module)
                arguments = _function_call_arguments(expression, function_name)
                evaluation_context = _function_evaluation_context(
                    function,
                    arguments,
                    functions,
                )
                next_sources: list[str] = []
                for source in current_sources:
                    for return_path in return_paths:
                        return_context = _evaluation_context_for_return_path(
                            return_path,
                            evaluation_context,
                        )
                        pattern_decisions = _pattern_decisions_for_return_path(
                            return_path,
                            return_context,
                            module,
                        )
                        transition_index += 1
                        target = _function_return_target(function_name, return_path["label"])
                        effect = {
                            "function": f"{namespace}.{function_name}",
                            "node_type": "FunctionIRNode",
                            "return_path": return_path["label"],
                            "return": to_json_value(return_path["expression"]),
                            "return_value": _ir_value_with_context(
                                return_path["expression"],
                                return_context,
                            ),
                            "branch_conditions": return_path.get("branch_conditions", []),
                            "match_conditions": return_path.get("match_conditions", []),
                            "evaluation_context": return_context,
                        }
                        if pattern_decisions:
                            effect["pattern_decisions"] = pattern_decisions
                        declarations.append(
                            semantic.TransitionNode(
                                f"{namespace}-function-{transition_index}",
                                target,
                                source,
                                "FunctionReturnTransition",
                                target,
                                effect=effect,
                            )
                        )
                        next_sources.append(target)
                current_sources = next_sources or current_sources
                emitted_function_returns.add(function_name)
            if isinstance(statement, (LetStatementNode, ConstStatementNode)):
                local_names.add(statement.identifier)
            if _terminates_with_result(statement):
                identifier = "result"
            target = (
                f"{node.name}.state.result"
                if identifier == "result"
                else f"{node.name}.state.{identifier}"
            )
            for source in current_sources:
                transition_index += 1
                transition_id = _calculation_transition_id(
                    node.name,
                    index,
                    identifier,
                    transition_index,
                    current_sources,
                )
                declarations.append(
                    semantic.TransitionNode(
                        f"{namespace}-calculation-{transition_index}",
                        transition_id,
                        source,
                        relation,
                        target,
                        effect={
                            "calculation": node.name,
                            "visibility": node.visibility.value,
                            "goal_annotation": node.goal_annotation,
                            "return_type": (
                                to_json_value(node.return_type)
                                if node.return_type is not None
                                else None
                            ),
                            "target": identifier,
                            "statement": statement_data,
                            "inputs": _resolved_expression_inputs(
                                expression,
                                calculation=node.name,
                                calculation_names=calculation_names,
                                local_names=local_names,
                            ),
                            "function_calls": [
                                {
                                    "node_type": "FunctionCallIRNode",
                                    "function": f"{namespace}.{function_name}",
                                    "arguments": [
                                        to_json_value(argument)
                                        for argument in _function_call_arguments(expression, function_name)
                                    ],
                                    "return_type": _type_label(
                                        functions[function_name].return_type
                                        if function_name in functions
                                        else None
                                    ),
                                }
                                for function_name in _expression_function_calls(expression)
                            ],
                            **(
                                {"expression": statement_data["expression"]}
                                if "expression" in statement_data
                                else {}
                            ),
                        },
                    )
                )
            current = target
            current_sources = [target]
            if isinstance(statement, AssignmentStatementNode):
                local_names.add(statement.target)
    return transition_index


def _exports(module: ModuleNode) -> list[str]:
    exports: list[str] = []
    for node in module.body:
        visibility = getattr(node, "visibility", None)
        if visibility == Visibility.PUBLIC and hasattr(node, "name"):
            exports.append(node.name)
    return exports


def _runtime_calls(module: ModuleNode) -> list[str]:
    calls: list[str] = []
    for node in module.body:
        for call in _walk_runtime_calls(node):
            if call.method not in calls:
                calls.append(call.method)
    return calls


def _runtime_operations(module: ModuleNode) -> list[dict[str, Any]]:
    operations = {
        RuntimeCallKind.INPUT: "InputOperation",
        RuntimeCallKind.PRINT: "PrintOperation",
        RuntimeCallKind.SEARCH: "RuntimeSearchNode",
        RuntimeCallKind.SIMULATION: "RuntimeSimulateNode",
        RuntimeCallKind.PREDICTION: "RuntimePredictNode",
        RuntimeCallKind.PLANNING: "RuntimePlanNode",
    }
    result: list[dict[str, Any]] = []
    for call in _walk_runtime_calls(module):
        argument = call.arguments[0] if call.arguments else None
        result.append(
            {
                "node_type": operations[call.kind],
                "operation": call.method,
                "method": call.method,
                "kind": call.kind.value,
                "argument": to_json_value(argument),
                "arguments": [to_json_value(item) for item in call.arguments],
                **(
                    {"source_state": _runtime_source_state(argument)}
                    if call.kind == RuntimeCallKind.PRINT and argument is not None
                    else {}
                ),
            }
        )
    return result


def _reason_object_bindings(module: ModuleNode, namespace: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for node in module.body:
        if not isinstance(node, ReasonObjectBindingNode):
            continue
        binding_id = "ruo-binding:" + hashlib.sha256(f"{namespace}:{node.name}".encode()).hexdigest()[:24]
        result.append({
            "node_type": "ReasonObjectBindingIR",
            "binding_id": binding_id,
            "lexical_name": node.name,
            "logical_source_ref": node.source_path,
            "resource_root_ref": node.resource_root,
            "load_mode": node.load_mode,
            "expected_object_id": node.expected_object_id,
            "capability_requirements": ["filesystem_read"],
            "input_type": "ReasonObjectBinding",
            "output_type": "ReasonObject",
            "failure_modes": ["capability", "integrity", "identity", "resource", "limit"],
            "determinism": "deterministic_for_verified_inputs",
            "source_span": to_json_value(node.source_span),
        })
    return result


_RUO_OUTPUT_TYPES = {"object_id": "StableId", "snapshot": "ReasonObjectSnapshot", "resolve": "ReasonEntityRef", "query": "ReasonQueryResult", "begin": "ReasonTransaction", "apply": "ReasonTransaction", "validate": "ReasonTransactionResult", "commit": "ReasonTransactionResult", "rollback": "ReasonTransactionResult", "select": "ReasonSelection", "materialize": "ReasonSelection", "project": "ReasonProjection", "save": "ReasonTransactionResult", "tensor_view": "ReasonTensorView", "status": "ReasonStatus", "diagnostics": "ReasonDiagnosticSet"}


def _reason_object_operations(module: ModuleNode) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for node in module.body:
        for call in _walk_ruo_calls(node):
            method = call.callee.member
            result.append({"node_type": "ReasonObjectOperationIR", "operation": method, "native_operation": method, "input_type": "typed", "output_type": _RUO_OUTPUT_TYPES[method], "arguments": [to_json_value(argument) for argument in call.arguments], "capability_requirement": "filesystem_write" if method == "save" else ("filesystem_read" if method in {"materialize", "tensor_view"} else None), "failure_modes": ["not_loaded", "unavailable", "invalid", "deleted", "stale", "conflict", "error"], "determinism": "deterministic"})
    return result


def _walk_ruo_calls(value: Any):
    if isinstance(value, CallExpressionNode) and isinstance(value.callee, MemberAccessNode) and isinstance(value.callee.object, IdentifierNode) and value.callee.object.name == "ruo":
        yield value
    if isinstance(value, tuple) or isinstance(value, list):
        for item in value: yield from _walk_ruo_calls(item)
    elif hasattr(value, "__dataclass_fields__"):
        for field in value.__dataclass_fields__: yield from _walk_ruo_calls(getattr(value, field))


def _function_symbols(module: ModuleNode, namespace: str) -> list[dict[str, Any]]:
    return [
        {
            "node_type": "FunctionSymbol",
            "name": node.name,
            "qualified_name": f"{namespace}.{node.name}",
            "parameters": [
                {
                    "name": _function_parameter_name(parameter),
                    "type": _type_label(_function_parameter_type(parameter)),
                }
                for parameter in node.parameters
            ],
            "return_type": _type_label(node.return_type),
        }
        for node in module.body
        if isinstance(node, FunctionDeclarationNode)
    ]


def _semantic_function_nodes(module: ModuleNode, namespace: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for node in module.body:
        if not isinstance(node, FunctionDeclarationNode):
            continue
        return_paths = _function_return_paths(node, module)
        result.append(
            {
                "node_type": "SemanticFunctionNode",
                "name": node.name,
                "qualified_name": f"{namespace}.{node.name}",
                "parameters": [
                    {
                        "name": _function_parameter_name(parameter),
                        "type": _type_label(_function_parameter_type(parameter)),
                    }
                    for parameter in node.parameters
                ],
                "return_type": _type_label(node.return_type),
                "body_type": (
                    _type_label(node.return_type) if return_paths else None
                ),
                "return_guaranteed": bool(return_paths),
                "return_paths": [path["label"] for path in return_paths],
                "pure": True,
            }
        )
    return result


def _function_ir_nodes(module: ModuleNode, namespace: str) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for node in module.body:
        if not isinstance(node, FunctionDeclarationNode):
            continue
        result.append(
            {
                "node_type": "FunctionIRNode",
                "id": f"{namespace}.{node.name}",
                "name": node.name,
                "return_type": _type_label(node.return_type),
                "pure": True,
                "parameters": [
                    {
                        "name": _function_parameter_name(parameter),
                        "type": _type_label(_function_parameter_type(parameter)),
                    }
                    for parameter in node.parameters
                ],
                "body": _function_control_flow_ir(node, module),
            }
        )
    return result


def _function_call_ir_nodes(module: ModuleNode, namespace: str) -> list[dict[str, Any]]:
    functions = {
        node.name: node for node in module.body if isinstance(node, FunctionDeclarationNode)
    }
    result: list[dict[str, Any]] = []
    for calculation in [node for node in module.body if isinstance(node, CalculationNode)]:
        for statement in calculation.body:
            expression = _statement_expression(statement)
            for function_name in _expression_function_calls(expression):
                function = functions.get(function_name)
                result.append(
                    {
                        "node_type": "FunctionCallIRNode",
                        "function": f"{namespace}.{function_name}",
                        "caller": calculation.name,
                        "arguments": [
                            _ir_value(argument)
                            for argument in _function_call_arguments(expression, function_name)
                        ],
                        "return_type": _type_label(
                            function.return_type if function is not None else None
                        ),
                    }
                )
    return result


def _function_call_dependencies(module: ModuleNode) -> dict[str, set[str]]:
    result: dict[str, set[str]] = {}
    functions = {
        node.name for node in module.body if isinstance(node, FunctionDeclarationNode)
    }
    for calculation in [node for node in module.body if isinstance(node, CalculationNode)]:
        dependencies: set[str] = set()
        for statement in calculation.body:
            dependencies.update(
                name
                for name in _expression_function_calls(_statement_expression(statement))
                if name in functions
            )
        result[calculation.name] = dependencies
    return result


def _function_parameter_name(parameter: Any) -> str:
    if isinstance(parameter, dict):
        return str(parameter.get("name", ""))
    return str(parameter)


def _function_parameter_type(parameter: Any) -> Any:
    if isinstance(parameter, dict):
        return parameter.get("type")
    return None


def _function_return_statement(function: FunctionDeclarationNode) -> ReturnStatementNode | None:
    for statement in reversed(function.body):
        if isinstance(statement, ReturnStatementNode):
            return statement
    return None


def _function_return_paths(
    function: FunctionDeclarationNode,
    module: ModuleNode | None = None,
) -> list[dict[str, Any]]:
    paths: list[dict[str, Any]] = []
    named_labels = _has_nested_if(function.body)

    def walk(
        statements: tuple[Any, ...],
        prefixes: list[tuple[str, ...]],
        branch_conditions: list[tuple[dict[str, Any], ...]],
        match_conditions: list[tuple[dict[str, Any], ...]],
    ) -> list[tuple[tuple[str, ...], tuple[dict[str, Any], ...]]]:
        active = prefixes
        active_conditions = branch_conditions
        active_match_conditions = match_conditions
        for statement in statements:
            if not active:
                return []
            if isinstance(statement, ReturnStatementNode):
                for prefix, conditions, matches in zip(
                    active,
                    active_conditions,
                    active_match_conditions,
                ):
                    paths.append(
                        {
                            "label": _return_path_label(prefix, len(paths) + 1),
                            "expression": statement.expression,
                            "branch_conditions": list(conditions),
                            "match_conditions": list(matches),
                        }
                    )
                return []
            if isinstance(statement, IfStatementNode):
                next_active: list[tuple[str, ...]] = []
                next_conditions: list[tuple[dict[str, Any], ...]] = []
                next_match_conditions: list[tuple[dict[str, Any], ...]] = []
                branches = [(True, statement.condition, statement.body)]
                branches.extend(
                    (True, branch.condition, branch.body)
                    for index, branch in enumerate(statement.elif_branches, 1)
                )
                for prefix, conditions, matches in zip(
                    active,
                    active_conditions,
                    active_match_conditions,
                ):
                    for branch_value, condition, body in branches:
                        label = _branch_label(condition, branch_value, named_labels)
                        branch_prefix = (*prefix, label)
                        branch_condition = _branch_condition(condition, branch_value)
                        if walk(
                            body,
                            [branch_prefix],
                            [(*conditions, branch_condition)],
                            [matches],
                        ):
                            next_active.append(branch_prefix)
                            next_conditions.append((*conditions, branch_condition))
                            next_match_conditions.append(matches)
                    if statement.else_branch is not None:
                        else_label = _branch_label(statement.condition, False, named_labels)
                        else_prefix = (*prefix, else_label)
                        branch_condition = _branch_condition(statement.condition, False)
                        if walk(
                            statement.else_branch.body,
                            [else_prefix],
                            [(*conditions, branch_condition)],
                            [matches],
                        ):
                            next_active.append(else_prefix)
                            next_conditions.append((*conditions, branch_condition))
                            next_match_conditions.append(matches)
                    else:
                        branch_condition = _branch_condition(statement.condition, False)
                        next_active.append((*prefix, _branch_label(statement.condition, False, named_labels)))
                        next_conditions.append((*conditions, branch_condition))
                        next_match_conditions.append(matches)
                active = next_active
                active_conditions = next_conditions
                active_match_conditions = next_match_conditions
                continue
            if isinstance(statement, MatchStatementNode):
                enum = _match_enum_declaration(statement, function, module) if module is not None else None
                next_active = []
                next_conditions = []
                next_match_conditions = []
                for prefix, conditions, matches in zip(
                    active,
                    active_conditions,
                    active_match_conditions,
                ):
                    for arm in statement.arms:
                        alternatives = _pattern_alternatives(arm.pattern)
                        for alternative_index, alternative in enumerate(alternatives):
                            label = _match_case_label(alternative, enum)
                            branch_prefix = (*prefix, label)
                            if arm.guard is not None:
                                branch_prefix = (*branch_prefix, f"match.{_guard_label(arm.guard)}")
                            match_condition = _match_condition(
                                statement,
                                arm,
                                _return_path_label(branch_prefix, 1),
                                function.name,
                                enum,
                                selected_pattern=alternative,
                                alternative_index=alternative_index,
                                alternative_count=len(alternatives),
                            )
                            if walk(
                                arm.body,
                                [branch_prefix],
                                [conditions],
                                [(*matches, match_condition)],
                            ):
                                next_active.append(branch_prefix)
                                next_conditions.append(conditions)
                                next_match_conditions.append((*matches, match_condition))
                active = next_active
                active_conditions = next_conditions
                active_match_conditions = next_match_conditions
                continue
        return list(zip(active, active_conditions))

    walk(function.body, [()], [()], [()])
    return paths


def _return_path_label(prefix: tuple[str, ...], index: int) -> str:
    if not prefix:
        return f"path_{index}"
    if all(item.startswith("match.") for item in prefix):
        return f"match.{_canonical_match_branch_id(prefix)}"
    if all(not item.endswith(("_true", "_false")) for item in prefix):
        return "_and_".join(prefix)
    separator = "_" if any("_" in item for item in prefix) else "."
    return separator.join(prefix)


def _canonical_match_branch_id(prefix: tuple[str, ...]) -> str:
    return "|".join(item.removeprefix("match.") for item in prefix)


def _canonical_match_path(prefix: tuple[str, ...]) -> list[str]:
    return [item.removeprefix("match.") for item in prefix if item.startswith("match.")]


def _function_return_target(function_name: str, label: str) -> str:
    if label.startswith("match."):
        return f"{function_name}.{label}"
    return f"{function_name}.return" if label == "path_1" else f"{function_name}.return.{label}"


def _function_control_flow_ir(
    function: FunctionDeclarationNode,
    module: ModuleNode,
) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    return_targets = {
        path["label"]: _function_return_target(function.name, path["label"])
        for path in _function_return_paths(function, module)
    }
    named_labels = _has_nested_if(function.body)

    def add_branch_nodes(statements: tuple[Any, ...], prefix: tuple[str, ...] = ()) -> None:
        for statement in statements:
            if isinstance(statement, MatchStatementNode):
                coverage = _match_coverage(statement, function, module)
                enum = _match_enum_declaration(statement, function, module)
                nodes.append(
                    {
                        "node_type": "MatchExpressionIRNode",
                        "value": _match_value_name(statement.expression),
                        "expression": to_json_value(statement.expression),
                        "cases": [
                            {
                                "node_type": "MatchCaseIRNode",
                                "pattern": _match_pattern_value(alternative, enum),
                                "target": _function_return_target(
                                    function.name,
                                    _return_path_label(
                                        _match_arm_prefix(
                                            prefix,
                                            arm,
                                            enum,
                                            selected_pattern=alternative,
                                        ),
                                        1,
                                    ),
                                ),
                                **_or_pattern_metadata(arm.pattern, alternative_index, len(alternatives), enum),
                            }
                            for arm in statement.arms
                            for alternatives in (_pattern_alternatives(arm.pattern),)
                            for alternative_index, alternative in enumerate(alternatives)
                        ],
                        **({"coverage": coverage} if coverage is not None else {}),
                    }
                )
                nodes.append(
                    {
                        "node_type": "PatternDecisionNode",
                        "input": _match_value_name(statement.expression),
                        "expression": to_json_value(statement.expression),
                        "arms": [
                            {
                                "branch_index": index,
                                "pattern": _pattern_decision_value(alternative, enum),
                                "target_transition": _function_return_target(
                                    function.name,
                                    _return_path_label(
                                        _match_arm_prefix(
                                            prefix,
                                            arm,
                                            enum,
                                            selected_pattern=alternative,
                                        ),
                                        1,
                                    ),
                                ),
                                **_or_pattern_metadata(arm.pattern, alternative_index, len(alternatives), enum),
                            }
                            for index, arm in enumerate(statement.arms)
                            for alternatives in (_pattern_alternatives(arm.pattern),)
                            for alternative_index, alternative in enumerate(alternatives)
                        ],
                        "selected_arm": None,
                    }
                )
                for arm in statement.arms:
                    alternatives = _pattern_alternatives(arm.pattern)
                    for alternative_index, alternative in enumerate(alternatives):
                        branch_prefix = _match_arm_prefix(
                            prefix,
                            arm,
                            enum,
                            selected_pattern=alternative,
                        )
                        label = _return_path_label(branch_prefix, 1)
                        pattern_identity = _pattern_identity(
                            _function_return_target(function.name, label),
                            alternative,
                            guarded=arm.guard is not None,
                            nested=len(_canonical_match_path(branch_prefix)) > 1,
                        )
                        if arm.guard is not None:
                            nodes.append(_guard_expression_ir(arm.guard))
                        nodes.append(
                            {
                                "node_type": "MatchSelectionIRNode",
                                "value": _match_value_name(statement.expression),
                                "pattern": _match_pattern_value(alternative, enum),
                                "target": _function_return_target(function.name, label),
                                "canonical_path": _canonical_match_path(branch_prefix),
                                "pattern_identity": pattern_identity,
                                **_or_pattern_metadata(arm.pattern, alternative_index, len(alternatives), enum),
                                **(
                                    {"guard": _guard_expression_ir(arm.guard)}
                                    if arm.guard is not None
                                    else {}
                                ),
                            }
                        )
                        add_branch_nodes(
                            arm.body,
                            branch_prefix,
                        )
                continue
            if not isinstance(statement, IfStatementNode):
                continue
            true_prefix = (*prefix, _branch_label(statement.condition, True, named_labels))
            false_prefix = (*prefix, _branch_label(statement.condition, False, named_labels))
            true_label = _first_return_label(statement.body, _return_path_label(true_prefix, 1))
            false_label = (
                _first_return_label(statement.else_branch.body, _return_path_label(false_prefix, 1))
                if statement.else_branch is not None
                else _return_path_label(false_prefix, 1)
            )
            nodes.append(
                {
                    "node_type": "ConditionalBranchIRNode",
                    "condition": to_json_value(statement.condition),
                    "condition_type": "Bool",
                    "true_target": return_targets.get(
                        true_label, _function_return_target(function.name, true_label)
                    ),
                    "false_target": return_targets.get(false_label, "fallthrough"),
                }
            )
            add_branch_nodes(statement.body, true_prefix)
            if statement.else_branch is not None:
                add_branch_nodes(statement.else_branch.body, false_prefix)

    add_branch_nodes(function.body)
    for path in _function_return_paths(function, module):
        nodes.append(
            {
                "node_type": "ReturnIRNode",
                "id": _function_return_target(function.name, path["label"]),
                "path": path["label"],
                "expression": to_json_value(path["expression"]),
                "return_value": _ir_value(path["expression"]),
                **(
                    {"semantic_reference": _enum_variant_reference(path["expression"].expression)}
                    if isinstance(path["expression"], ExpressionNode)
                    and _enum_variant_reference(path["expression"].expression) is not None
                    else {}
                ),
            }
        )
    if any(isinstance(statement, (IfStatementNode, MatchStatementNode)) for statement in function.body):
        nodes.append({"node_type": "MergeIRNode", "id": f"{function.name}.merge.return"})
    return nodes


def _first_return_label(statements: tuple[Any, ...], default: str) -> str:
    for statement in statements:
        if isinstance(statement, ReturnStatementNode):
            return default
    return default


def _has_nested_if(statements: tuple[Any, ...], *, inside_if: bool = False) -> bool:
    for statement in statements:
        if not isinstance(statement, IfStatementNode):
            continue
        if inside_if:
            return True
        if _has_nested_if(statement.body, inside_if=True):
            return True
        if statement.else_branch is not None and _has_nested_if(
            statement.else_branch.body,
            inside_if=True,
        ):
            return True
    return False


def _branch_label(condition: ExpressionNode, value: bool, named_labels: bool) -> str:
    suffix = "true" if value else "false"
    if not named_labels:
        return suffix
    name = _condition_name(condition)
    if name and _is_comparison_condition(condition):
        return name if value else f"not_{name}"
    return f"{name}_{suffix}" if name else suffix


def _branch_condition(condition: ExpressionNode, expected_value: bool) -> dict[str, Any]:
    result = {
        "condition": _condition_name(condition) or _condition_literal_name(condition),
        "condition_type": "Bool",
        "expected_value": expected_value,
        "expression": to_json_value(condition),
    }
    comparison = _comparison_ir(condition)
    if comparison is not None:
        result["comparison"] = comparison
    return result


def _match_arm_prefix(
    prefix: tuple[str, ...],
    arm: Any,
    enum: EnumDeclarationNode | None,
    *,
    selected_pattern: PatternNode | None = None,
) -> tuple[str, ...]:
    result = (*prefix, _match_case_label(selected_pattern or arm.pattern, enum))
    if getattr(arm, "guard", None) is not None:
        result = (*result, f"match.{_guard_label(arm.guard)}")
    return result


def _match_condition(
    statement: MatchStatementNode,
    arm: Any,
    label: str,
    function_name: str,
    enum: EnumDeclarationNode | None = None,
    *,
    selected_pattern: PatternNode | None = None,
    alternative_index: int = 0,
    alternative_count: int = 1,
) -> dict[str, Any]:
    pattern = selected_pattern or arm.pattern
    pattern_id = _function_return_target(function_name, label)
    return {
        "node_type": "MatchSelectionIRNode",
        "value": _match_value_name(statement.expression),
        "expression": to_json_value(statement.expression),
        "pattern": _match_pattern_value(pattern, enum),
        "target": label,
        "pattern_identity": _pattern_identity(
            pattern_id,
            pattern,
            guarded=arm.guard is not None,
            nested="|" in pattern_id and "|guard." not in pattern_id,
        ),
        **_or_pattern_metadata(arm.pattern, alternative_index, alternative_count, enum),
        **(
            {"guard": _guard_expression_ir(arm.guard)}
            if arm.guard is not None
            else {}
        ),
    }


def _guard_label(expression: ExpressionNode) -> str:
    name = _condition_name(expression) or _condition_literal_name(expression)
    return f"guard.{name}"


def _guard_expression_ir(expression: ExpressionNode) -> dict[str, Any]:
    result = {
        "node_type": "GuardExpressionIRNode",
        "expression": _expression_text(expression),
        "expression_ast": to_json_value(expression),
        "result_type": "Bool",
    }
    comparison = _comparison_ir(expression)
    if comparison is not None:
        result["comparison"] = comparison
    return result


def _match_value_name(expression: ExpressionNode) -> str:
    value = expression.expression
    if isinstance(value, IdentifierNode):
        return value.name
    return _condition_operand_name(_comparison_operand(expression))


def _match_case_label(
    pattern: PatternNode,
    enum: EnumDeclarationNode | None = None,
) -> str:
    return f"match.{_match_pattern_label(pattern, enum)}"


def _match_pattern_label(
    pattern: PatternNode,
    enum: EnumDeclarationNode | None = None,
) -> str:
    value = _match_pattern_value(pattern, enum)
    if value == "default":
        return "default"
    if isinstance(value, bool):
        return "true" if value else "false"
    if _is_enum_value_pattern(value):
        return f"{value['enum_name']}.{value['value_name']}"
    if _is_optional_pattern(value):
        if value["node_type"] == "OptionalSomePatternNode":
            if "pattern" in value:
                inner = value["pattern"]
                if isinstance(inner, dict):
                    if _is_enum_value_pattern(inner):
                        return f"some.{inner['enum_name']}.{inner['value_name']}"
                    if inner.get("node_type") == "StructPatternNode":
                        return f"some.{_struct_pattern_signature(inner)}"
                return f"some.{str(inner).replace('-', 'neg_').replace('.', '_')}"
            return "some"
        return "none"
    if isinstance(value, dict) and value.get("node_type") == "StructPatternNode":
        return _struct_pattern_signature(value)
    if isinstance(value, dict) and value.get("node_type") == "RangePatternIRNode":
        return _range_pattern_label(value)
    return str(value).replace("-", "neg_").replace(".", "_")


def _pattern_identity(
    pattern_id: str,
    pattern: PatternNode,
    *,
    guarded: bool = False,
    nested: bool = False,
) -> dict[str, str]:
    return {
        "pattern_id": pattern_id,
        "pattern_type": _pattern_identity_type(pattern, guarded=guarded, nested=nested),
        "canonical_path": pattern_id,
    }


def _pattern_identity_type(
    pattern: PatternNode,
    *,
    guarded: bool = False,
    nested: bool = False,
) -> str:
    if guarded:
        return "Guard"
    if nested:
        return "NestedStruct"
    value = pattern.pattern
    if isinstance(value, LiteralPatternNode):
        return "Literal"
    if isinstance(value, RangePatternNode):
        return "Range"
    if isinstance(value, (QualifiedPatternNode, EnumValuePatternNode)):
        return "Enum"
    if isinstance(value, (OptionalPatternNode, OptionalValuePatternNode)):
        return "Optional"
    if isinstance(value, StructPatternNode):
        return "NestedStruct" if _struct_pattern_contains_nested_struct(value) else "Struct"
    if isinstance(value, OrPatternNode):
        return "OrAlternative"
    return "Literal"


def _struct_pattern_contains_nested_struct(pattern: StructPatternNode) -> bool:
    for field in pattern.fields:
        field_pattern = field.pattern
        if isinstance(field_pattern, StructPatternNode):
            return True
        if isinstance(field_pattern, OrPatternNode):
            if any(
                isinstance(alternative, StructPatternNode)
                and _struct_pattern_contains_nested_struct(alternative)
                for alternative in field_pattern.alternatives
            ):
                return True
    return False


def _match_pattern_value(
    pattern: PatternNode,
    enum: EnumDeclarationNode | None = None,
) -> Any:
    value = pattern.pattern
    if isinstance(value, WildcardPatternNode):
        return "wildcard"
    if isinstance(value, DefaultPatternNode) or (
        isinstance(value, IdentifierPatternNode) and value.name == "default"
    ):
        return "default"
    if isinstance(value, LiteralPatternNode):
        literal = value.value
        if isinstance(literal, (BooleanLiteralNode, IntegerLiteralNode, FloatLiteralNode)):
            return literal.value
        if isinstance(literal, StringLiteralNode):
            return literal.value
    if isinstance(value, RangePatternNode):
        return {
            "node_type": "RangePatternIRNode",
            "lower": value.lower.value,
            "upper": value.upper.value,
            "lower_inclusive": value.lower_inclusive,
            "upper_inclusive": value.upper_inclusive,
        }
    if isinstance(value, QualifiedPatternNode):
        return {
            "node_type": "EnumValuePatternNode",
            "enum_name": value.namespace,
            "value_name": value.identifier,
        }
    if isinstance(value, EnumValuePatternNode):
        return {
            "node_type": "EnumValuePatternNode",
            "enum_name": value.enum_name,
            "value_name": value.value_name,
        }
    if isinstance(value, OptionalPatternNode):
        if value.kind == "Some":
            return {
                "node_type": "OptionalSomePatternNode",
                "binding": value.binding,
            }
        return {
            "node_type": "OptionalNonePatternNode",
        }
    if isinstance(value, OptionalValuePatternNode):
        return {
            "node_type": "OptionalSomePatternNode",
            "pattern": _match_pattern_value(PatternNode(value.pattern), enum),
        }
    if isinstance(value, OrPatternNode):
        return _or_pattern_ir(value, enum)
    if isinstance(value, StructPatternNode):
        return to_json_value(value)
    return to_json_value(pattern)


def _pattern_alternatives(pattern: PatternNode) -> tuple[PatternNode, ...]:
    value = pattern.pattern
    if isinstance(value, OrPatternNode):
        return tuple(PatternNode(alternative) for alternative in value.alternatives)
    return (pattern,)


def _or_pattern_ir(
    pattern: OrPatternNode,
    enum: EnumDeclarationNode | None = None,
) -> dict[str, Any]:
    return {
        "node_type": "OrPatternIRNode",
        "alternatives": [
            _match_pattern_value(PatternNode(alternative), enum)
            for alternative in pattern.alternatives
        ],
    }


def _or_pattern_metadata(
    source_pattern: PatternNode,
    alternative_index: int,
    alternative_count: int,
    enum: EnumDeclarationNode | None = None,
) -> dict[str, Any]:
    value = source_pattern.pattern
    if not isinstance(value, OrPatternNode):
        return {}
    return {
        "or_pattern": {
            **_or_pattern_ir(value, enum),
            "selected_index": alternative_index,
            "selected_pattern": _match_pattern_label(
                PatternNode(value.alternatives[alternative_index]),
                enum,
            ),
            "alternative_count": alternative_count,
        }
    }


def _struct_pattern_signature(pattern: dict[str, Any]) -> str:
    type_name = str(pattern.get("type_name", "Struct"))
    field_labels: list[str] = []
    for field in pattern.get("fields") or []:
        label = _struct_field_pattern_label(field)
        if label is not None:
            field_labels.append(label)
    return f"{type_name}.{('_'.join(field_labels))}" if field_labels else type_name


def _range_pattern_label(pattern: dict[str, Any]) -> str:
    lower = _range_bound_label(pattern.get("lower"))
    upper = _range_bound_label(pattern.get("upper"))
    separator = "_" if pattern.get("upper_inclusive", True) else "_lt_"
    return f"range.{lower}{separator}{upper}"


def _range_bound_label(value: Any) -> str:
    text = str(value)
    text = text.removesuffix(".0")
    return text.replace("-", "neg_").replace(".", "_")


def _struct_field_pattern_label(field: Any) -> str | None:
    if not isinstance(field, dict):
        return None
    field_name = str(field.get("field_name") or "")
    pattern = field.get("pattern")
    if not isinstance(pattern, dict):
        return None
    node_type = pattern.get("node_type")
    if node_type == "StructPatternNode":
        return f"{field_name}|{_struct_pattern_signature(pattern)}"
    if node_type == "StructBindingPatternNode":
        return f"bind{pattern.get('binding')}"
    if node_type == "IdentifierPatternNode":
        return f"bind{pattern.get('name')}"
    if node_type == "QualifiedPatternNode":
        return f"{pattern.get('namespace')}.{pattern.get('identifier')}"
    if node_type == "EnumValuePatternNode":
        return f"{pattern.get('enum_name')}.{pattern.get('value_name')}"
    if node_type == "LiteralPatternNode":
        literal = pattern.get("value")
        if isinstance(literal, dict):
            return f"{field_name}{literal.get('value')}"
        return f"{field_name}{literal}"
    if node_type == "WildcardPatternNode":
        return f"{field_name}wildcard"
    return None


def _pattern_decisions_for_return_path(
    return_path: dict[str, Any],
    context: dict[str, Any],
    module: ModuleNode,
) -> list[dict[str, Any]]:
    decisions: list[dict[str, Any]] = []
    symbols = _module_symbols(module)
    for condition in return_path.get("match_conditions", []):
        pattern = condition.get("pattern")
        if not (
            isinstance(pattern, dict)
            and pattern.get("node_type") == "StructPatternNode"
        ):
            continue
        value = context.get(condition.get("value"))
        runtime_value = _runtime_struct_value(value)
        if runtime_value is None:
            continue
        try:
            semantic_pattern = resolve_struct_pattern(
                StructPatternNode(
                    str(pattern["type_name"]),
                    tuple(
                        _struct_pattern_field_from_json(field)
                        for field in pattern.get("fields", [])
                    ),
                ),
                symbols,
            )
        except StructPatternSemanticError:
            continue
        match_result = PatternEvaluator().evaluate(semantic_pattern, runtime_value)
        decision = PatternDecisionBuilder().build(
            match_result,
            matched_pattern=semantic_pattern.struct_symbol,
            branch_id=_pattern_branch_id(condition.get("target")),
            source_span=semantic_pattern.source_span,
        )
        decisions.append(pattern_decision_to_json(decision))
    return decisions


def _struct_pattern_has_nested_field(pattern: dict[str, Any]) -> bool:
    for field in pattern.get("fields") or []:
        field_pattern = field.get("pattern")
        if (
            isinstance(field_pattern, dict)
            and field_pattern.get("node_type") == "StructPatternNode"
        ):
            return True
    return False


def _runtime_struct_value(value: Any) -> RuntimeStructValue | None:
    if not isinstance(value, dict):
        return None
    type_name = value.get("struct_type") or value.get("type_name")
    fields = value.get("fields")
    if not isinstance(type_name, str) or not isinstance(fields, dict):
        return None
    return RuntimeStructValue.from_mapping(
        type_name,
        {name: _runtime_pattern_value(item) for name, item in fields.items()},
    )


def _runtime_pattern_value(value: Any) -> Any:
    if isinstance(value, dict):
        enum = value.get("enum") or value.get("enum_name")
        variant = (
            value.get("variant")
            or value.get("variant_name")
            or value.get("value_name")
        )
        if isinstance(enum, str) and isinstance(variant, str):
            return RuntimeEnumValue(enum, variant)
        runtime_struct = _runtime_struct_value(value)
        if runtime_struct is not None:
            return runtime_struct
    return value


def _struct_pattern_field_from_json(value: dict[str, Any]) -> Any:
    from .nodes import StructFieldPatternNode, pattern_from_json

    return StructFieldPatternNode(
        str(value["field_name"]),
        pattern_from_json(
            {"node_type": "PatternNode", "pattern": value["pattern"]}
        ).pattern,
    )


def _module_symbols(module: ModuleNode) -> dict[str, Any]:
    return {node.name: node for node in module.body if hasattr(node, "name")}


def _pattern_branch_id(target: Any) -> str | None:
    if not isinstance(target, str):
        return None
    return target.removeprefix("match.")


def _pattern_decision_value(
    pattern: PatternNode,
    enum: EnumDeclarationNode | None = None,
) -> Any:
    value = pattern.pattern
    if isinstance(value, QualifiedPatternNode):
        return {
            "node_type": "EnumVariantReferenceNode",
            "enum": value.namespace,
            "variant": value.identifier,
            "symbol_id": f"{value.namespace}.{value.identifier}",
        }
    return _match_pattern_value(pattern, enum)


def _match_coverage(
    statement: MatchStatementNode,
    function: FunctionDeclarationNode,
    module: ModuleNode,
) -> dict[str, Any] | None:
    enum = _match_enum_declaration(statement, function, module)
    if enum is None:
        return _struct_match_coverage(statement, function, module)
    explicit: list[str] = []
    for arm in statement.arms:
        if arm.guard is not None:
            continue
        for pattern_node in _pattern_alternatives(arm.pattern):
            pattern = pattern_node.pattern
            if isinstance(pattern, EnumValuePatternNode) and pattern.enum_name == enum.name:
                explicit.append(f"{pattern.enum_name}.{pattern.value_name}")
            elif isinstance(pattern, QualifiedPatternNode) and pattern.namespace == enum.name:
                explicit.append(f"{pattern.namespace}.{pattern.identifier}")
    default_present = any(
        _pattern_key in {"default", "wildcard"}
        for _pattern_key in (
            _match_pattern_kind(arm.pattern)
            for arm in statement.arms
            if arm.guard is None
        )
    )
    all_variants = [f"{enum.name}.{value.name}" for value in enum.values]
    covered = all_variants if default_present else [item for item in all_variants if item in explicit]
    return {
        "enum_name": enum.name,
        "explicit_variants": explicit,
        "default_present": default_present,
        "covered_variants": covered,
        "missing_variants": [item for item in all_variants if item not in covered],
    }


def _struct_match_coverage(
    statement: MatchStatementNode,
    function: FunctionDeclarationNode,
    module: ModuleNode,
) -> dict[str, Any] | None:
    struct = _match_struct_declaration(statement, function, module)
    if struct is None:
        return None
    default_present = any(
        _pattern_key in {"default", "wildcard"}
        for _pattern_key in (
            _match_pattern_kind(arm.pattern)
            for arm in statement.arms
            if arm.guard is None
        )
    )
    struct_patterns = [
        pattern_node.pattern
        for arm in statement.arms
        if arm.guard is None
        for pattern_node in _pattern_alternatives(arm.pattern)
        if isinstance(pattern_node.pattern, StructPatternNode)
        and pattern_node.pattern.type_name.split(".")[-1] == struct.name
    ]
    binding_pattern_present = any(
        _struct_pattern_is_binding_only(pattern) for pattern in struct_patterns
    )
    empty_pattern_present = any(not pattern.fields for pattern in struct_patterns)
    exhaustive_pattern_present = any(
        _struct_pattern_is_exhaustive(pattern) for pattern in struct_patterns
    )
    complete = default_present or binding_pattern_present or empty_pattern_present or exhaustive_pattern_present
    return {
        "struct_name": struct.name,
        "binding_pattern_present": binding_pattern_present,
        "empty_pattern_present": empty_pattern_present,
        "default_present": default_present,
        "coverage": "complete" if complete else "partial",
    }


def _match_enum_declaration(
    statement: MatchStatementNode,
    function: FunctionDeclarationNode,
    module: ModuleNode,
) -> EnumDeclarationNode | None:
    expression = statement.expression.expression
    if not isinstance(expression, IdentifierNode):
        return None
    parameter_type = None
    for parameter in function.parameters:
        if _function_parameter_name(parameter) == expression.name:
            parameter_type = _function_parameter_type(parameter)
            break
    if not isinstance(parameter_type, NamedTypeNode):
        return None
    for node in module.body:
        if isinstance(node, EnumDeclarationNode) and node.name == parameter_type.name:
            return node
    return None


def _match_struct_declaration(
    statement: MatchStatementNode,
    function: FunctionDeclarationNode,
    module: ModuleNode,
) -> StructDeclarationNode | None:
    expression = statement.expression.expression
    if not isinstance(expression, IdentifierNode):
        return None
    parameter_type = None
    for parameter in function.parameters:
        if _function_parameter_name(parameter) == expression.name:
            parameter_type = _function_parameter_type(parameter)
            break
    if not isinstance(parameter_type, NamedTypeNode):
        return None
    for node in module.body:
        if isinstance(node, StructDeclarationNode) and node.name == parameter_type.name:
            return node
    return None


def _struct_pattern_is_binding_only(pattern: StructPatternNode) -> bool:
    return bool(pattern.fields) and all(
        isinstance(field.pattern, (StructBindingPatternNode, IdentifierPatternNode))
        for field in pattern.fields
    )


def _struct_pattern_is_exhaustive(pattern: StructPatternNode) -> bool:
    if not pattern.fields:
        return True
    return all(_struct_field_pattern_is_exhaustive(field.pattern) for field in pattern.fields)


def _struct_field_pattern_is_exhaustive(pattern: Any) -> bool:
    if isinstance(pattern, (StructBindingPatternNode, IdentifierPatternNode, WildcardPatternNode)):
        return True
    if isinstance(pattern, StructPatternNode):
        return _struct_pattern_is_exhaustive(pattern)
    return False


def _match_pattern_kind(pattern: PatternNode) -> str:
    value = pattern.pattern
    if isinstance(value, WildcardPatternNode):
        return "wildcard"
    if isinstance(value, DefaultPatternNode) or (
        isinstance(value, IdentifierPatternNode) and value.name == "default"
    ):
        return "default"
    return "pattern"


def _is_enum_value_pattern(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("node_type") == "EnumValuePatternNode"
        and isinstance(value.get("enum_name"), str)
        and isinstance(value.get("value_name"), str)
    )


def _is_optional_pattern(value: Any) -> bool:
    return (
        isinstance(value, dict)
        and value.get("node_type")
        in {"OptionalSomePatternNode", "OptionalNonePatternNode"}
    )


def _condition_name(condition: ExpressionNode) -> str | None:
    expression = condition.expression
    if isinstance(expression, IdentifierNode):
        return expression.name
    if isinstance(expression, ParenthesizedExpressionNode) and isinstance(
        expression.expression,
        IdentifierNode,
    ):
        return expression.expression.name
    comparison = _comparison_ir(condition)
    if comparison is not None:
        return _comparison_condition_name(comparison)
    return None


def _condition_literal_name(condition: ExpressionNode) -> str:
    expression = condition.expression
    if isinstance(expression, BooleanLiteralNode):
        return "true" if expression.value else "false"
    return "<unsupported>"


_COMPARISON_OPERATOR_SYMBOLS = {
    ComparisonOperator.EQUAL: "==",
    ComparisonOperator.NOT_EQUAL: "!=",
    ComparisonOperator.GREATER_THAN: ">",
    ComparisonOperator.GREATER_THAN_OR_EQUAL: ">=",
    ComparisonOperator.LESS_THAN: "<",
    ComparisonOperator.LESS_THAN_OR_EQUAL: "<=",
}


_COMPARISON_OPERATOR_NAMES = {
    "==": "eq",
    "!=": "ne",
    ">": "gt",
    ">=": "gte",
    "<": "lt",
    "<=": "lte",
}


def _is_comparison_condition(condition: ExpressionNode) -> bool:
    return _comparison_ir(condition) is not None


def _comparison_ir(condition: ExpressionNode) -> dict[str, Any] | None:
    value = condition.expression
    if isinstance(value, ParenthesizedExpressionNode):
        value = value.expression.expression
    if not isinstance(value, ComparisonExpressionNode):
        return None
    return {
        "node_type": "ComparisonExpressionIRNode",
        "operator": _COMPARISON_OPERATOR_SYMBOLS[value.operator],
        "left": _comparison_operand(value.left),
        "right": _comparison_operand(value.right),
        "result_type": "Bool",
    }


def _comparison_operand(expression: ExpressionNode) -> Any:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    if isinstance(value, IdentifierNode):
        return value.name
    if isinstance(value, BooleanLiteralNode):
        return value.value
    if value.__class__.__name__ in {"IntegerLiteralNode", "FloatLiteralNode"}:
        return value.value
    return to_json_value(expression)


def _comparison_condition_name(comparison: dict[str, Any]) -> str:
    left = _condition_operand_name(comparison.get("left"))
    right = _condition_operand_name(comparison.get("right"))
    operator = _COMPARISON_OPERATOR_NAMES.get(str(comparison.get("operator")), "cmp")
    return f"{left}_{operator}_{right}"


def _expression_text(expression: ExpressionNode) -> str:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    if isinstance(value, IdentifierNode):
        return value.name
    if isinstance(value, BooleanLiteralNode):
        return "true" if value.value else "false"
    if isinstance(value, (IntegerLiteralNode, FloatLiteralNode)):
        return str(value.value)
    if isinstance(value, ComparisonExpressionNode):
        return (
            f"{_expression_text(value.left)} "
            f"{_COMPARISON_OPERATOR_SYMBOLS[value.operator]} "
            f"{_expression_text(value.right)}"
        )
    if isinstance(value, ParenthesizedExpressionNode):
        return f"({_expression_text(value.expression)})"
    return str(_ir_value(expression))


def _condition_operand_name(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value).replace("-", "neg_").replace(".", "_")
    if isinstance(value, str):
        return "".join(ch if ch.isalnum() else "_" for ch in value).strip("_") or "value"
    return "value"


def _function_evaluation_context(
    function: FunctionDeclarationNode,
    arguments: tuple[Any, ...],
    functions: dict[str, FunctionDeclarationNode] | None = None,
) -> dict[str, Any]:
    context: dict[str, Any] = {}
    for parameter, argument in zip(function.parameters, arguments):
        value = _compile_time_value(argument, {}, functions or {}, ())
        context[_function_parameter_name(parameter)] = (
            _literal_value(argument) if value is _UNKNOWN_VALUE else value
        )
    return context


_UNKNOWN_VALUE = object()
_NO_RETURN = object()


def _compile_time_value(
    expression: Any,
    context: dict[str, Any],
    functions: dict[str, FunctionDeclarationNode],
    active_calls: tuple[str, ...],
) -> Any:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    if isinstance(value, BooleanLiteralNode):
        return value.value
    if isinstance(value, (IntegerLiteralNode, FloatLiteralNode)):
        return value.value
    if isinstance(value, IdentifierNode):
        return context.get(value.name, _UNKNOWN_VALUE)
    if isinstance(value, ParenthesizedExpressionNode):
        return _compile_time_value(value.expression, context, functions, active_calls)
    if isinstance(value, UnaryExpressionNode):
        operand = _compile_time_value(value.operand, context, functions, active_calls)
        if operand is _UNKNOWN_VALUE:
            return _UNKNOWN_VALUE
        if value.operator == UnaryOperator.NEGATE and isinstance(operand, (int, float)):
            return -operand
        if value.operator == UnaryOperator.NOT and isinstance(operand, bool):
            return not operand
        return _UNKNOWN_VALUE
    if isinstance(value, BinaryExpressionNode):
        left = _compile_time_value(value.left, context, functions, active_calls)
        right = _compile_time_value(value.right, context, functions, active_calls)
        return _compile_time_binary(value.operator, left, right)
    if isinstance(value, ComparisonExpressionNode):
        left = _compile_time_value(value.left, context, functions, active_calls)
        right = _compile_time_value(value.right, context, functions, active_calls)
        return _compile_time_comparison(value.operator, left, right)
    if isinstance(value, LogicalExpressionNode):
        left = _compile_time_value(value.left, context, functions, active_calls)
        right = _compile_time_value(value.right, context, functions, active_calls)
        if not isinstance(left, bool) or not isinstance(right, bool):
            return _UNKNOWN_VALUE
        return left and right if value.operator == LogicalOperator.AND else left or right
    if (
        isinstance(value, CallExpressionNode)
        and isinstance(value.callee, IdentifierNode)
        and value.callee.name in functions
        and value.callee.name not in active_calls
    ):
        function = functions[value.callee.name]
        arguments = [
            _compile_time_value(argument, context, functions, active_calls)
            for argument in value.arguments
        ]
        if any(argument is _UNKNOWN_VALUE for argument in arguments):
            return _UNKNOWN_VALUE
        call_context = {
            _function_parameter_name(parameter): argument
            for parameter, argument in zip(function.parameters, arguments)
        }
        result = _compile_time_function_body(
            function.body,
            call_context,
            functions,
            (*active_calls, function.name),
        )
        return _UNKNOWN_VALUE if result is _NO_RETURN else result
    return _UNKNOWN_VALUE


def _compile_time_function_body(
    statements: tuple[Any, ...],
    context: dict[str, Any],
    functions: dict[str, FunctionDeclarationNode],
    active_calls: tuple[str, ...],
) -> Any:
    local_context = dict(context)
    for statement in statements:
        if isinstance(statement, ReturnStatementNode):
            return _compile_time_value(
                statement.expression,
                local_context,
                functions,
                active_calls,
            )
        if isinstance(statement, (LetStatementNode, ConstStatementNode)):
            value = _compile_time_value(
                statement.expression,
                local_context,
                functions,
                active_calls,
            )
            if value is _UNKNOWN_VALUE:
                return _UNKNOWN_VALUE
            local_context[statement.identifier] = value
            continue
        if isinstance(statement, AssignmentStatementNode):
            value = _compile_time_value(
                statement.expression,
                local_context,
                functions,
                active_calls,
            )
            if value is _UNKNOWN_VALUE:
                return _UNKNOWN_VALUE
            local_context[statement.target] = value
            continue
        if isinstance(statement, IfStatementNode):
            branches = (
                (statement.condition, statement.body),
                *((branch.condition, branch.body) for branch in statement.elif_branches),
            )
            selected_body = None
            for condition, body in branches:
                selected = _compile_time_value(
                    condition,
                    local_context,
                    functions,
                    active_calls,
                )
                if not isinstance(selected, bool):
                    return _UNKNOWN_VALUE
                if selected:
                    selected_body = body
                    break
            if selected_body is None and statement.else_branch is not None:
                selected_body = statement.else_branch.body
            if selected_body is not None:
                result = _compile_time_function_body(
                    selected_body,
                    local_context,
                    functions,
                    active_calls,
                )
                if result is not _NO_RETURN:
                    return result
    return _NO_RETURN


def _compile_time_binary(operator: BinaryOperator, left: Any, right: Any) -> Any:
    if (
        left is _UNKNOWN_VALUE
        or right is _UNKNOWN_VALUE
        or isinstance(left, bool)
        or isinstance(right, bool)
        or not isinstance(left, (int, float))
        or not isinstance(right, (int, float))
    ):
        return _UNKNOWN_VALUE
    if operator == BinaryOperator.ADD:
        return left + right
    if operator == BinaryOperator.SUBTRACT:
        return left - right
    if operator == BinaryOperator.MULTIPLY:
        return left * right
    if operator == BinaryOperator.DIVIDE and right != 0:
        return left / right
    if operator == BinaryOperator.MODULO and right != 0:
        return left % right
    return _UNKNOWN_VALUE


def _compile_time_comparison(
    operator: ComparisonOperator,
    left: Any,
    right: Any,
) -> Any:
    if left is _UNKNOWN_VALUE or right is _UNKNOWN_VALUE:
        return _UNKNOWN_VALUE
    if operator == ComparisonOperator.EQUAL:
        return left == right
    if operator == ComparisonOperator.NOT_EQUAL:
        return left != right
    if (
        isinstance(left, bool)
        or isinstance(right, bool)
        or not isinstance(left, (int, float))
        or not isinstance(right, (int, float))
    ):
        return _UNKNOWN_VALUE
    if operator == ComparisonOperator.GREATER_THAN:
        return left > right
    if operator == ComparisonOperator.GREATER_THAN_OR_EQUAL:
        return left >= right
    if operator == ComparisonOperator.LESS_THAN:
        return left < right
    if operator == ComparisonOperator.LESS_THAN_OR_EQUAL:
        return left <= right
    return _UNKNOWN_VALUE


def _evaluation_context_for_return_path(
    return_path: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    result = dict(context)
    for condition in return_path.get("match_conditions", []):
        pattern = condition.get("pattern")
        if not (
            isinstance(pattern, dict)
            and pattern.get("node_type") in {"OptionalSomePatternNode", "StructPatternNode"}
        ):
            continue
        if pattern.get("node_type") == "OptionalSomePatternNode":
            if not isinstance(pattern.get("binding"), str):
                continue
            optional_value = result.get(condition.get("value"))
            if isinstance(optional_value, dict) and optional_value.get("kind") == "some":
                result[pattern["binding"]] = optional_value.get("value")
            continue
        struct_value = result.get(condition.get("value"))
        result.update(_struct_pattern_bindings(pattern, struct_value))
    return result


def _struct_pattern_bindings(pattern: dict[str, Any], value: Any) -> dict[str, Any]:
    if not isinstance(pattern, dict) or not isinstance(value, dict):
        return {}
    if pattern.get("node_type") != "StructPatternNode":
        return {}
    fields = value.get("fields")
    if not isinstance(fields, dict):
        return {}
    bindings: dict[str, Any] = {}
    for field in pattern.get("fields") or []:
        if not isinstance(field, dict):
            continue
        field_name = field.get("field_name")
        if not isinstance(field_name, str) or field_name not in fields:
            continue
        field_pattern = field.get("pattern")
        if not isinstance(field_pattern, dict):
            continue
        if field_pattern.get("node_type") == "StructBindingPatternNode":
            binding = field_pattern.get("binding")
            if isinstance(binding, str):
                bindings[binding] = fields[field_name]
        elif field_pattern.get("node_type") == "IdentifierPatternNode":
            binding = field_pattern.get("name")
            if isinstance(binding, str):
                bindings[binding] = fields[field_name]
        elif field_pattern.get("node_type") == "StructPatternNode":
            bindings.update(_struct_pattern_bindings(field_pattern, fields[field_name]))
        elif field_pattern.get("node_type") == "OrPatternNode":
            for alternative in field_pattern.get("alternatives") or []:
                if not isinstance(alternative, dict):
                    continue
                if alternative.get("node_type") == "StructPatternNode":
                    if _struct_pattern_bindings(alternative, fields[field_name]):
                        bindings.update(_struct_pattern_bindings(alternative, fields[field_name]))
                        break
                elif alternative.get("node_type") == "StructBindingPatternNode":
                    binding = alternative.get("binding")
                    if isinstance(binding, str):
                        bindings[binding] = fields[field_name]
                        break
                elif alternative.get("node_type") == "IdentifierPatternNode":
                    binding = alternative.get("name")
                    if isinstance(binding, str):
                        bindings[binding] = fields[field_name]
                        break
    return bindings


def _literal_value(expression: Any) -> Any:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    if isinstance(value, BooleanLiteralNode):
        return value.value
    if value.__class__.__name__ == "IntegerLiteralNode":
        return value.value
    if value.__class__.__name__ == "FloatLiteralNode":
        return value.value
    enum_value = _enum_variant_ir(value)
    if enum_value is not None:
        return {
            "enum": enum_value["enum_name"],
            "variant": enum_value["variant_name"],
        }
    if isinstance(value, StructLiteralNode):
        return {
            "struct_type": value.type_name,
            "fields": {
                field.field_name: _literal_value(field.expression)
                for field in value.fields
            },
        }
    if isinstance(value, SomeExpressionNode):
        return {
            "kind": "some",
            "value": _literal_value(value.value),
        }
    if isinstance(value, NoneLiteralNode):
        return {
            "kind": "none",
        }
    return to_json_value(expression)


def _ir_value(expression: Any) -> Any:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    enum_value = _enum_variant_ir(value)
    if enum_value is not None:
        return enum_value
    return to_json_value(expression)


def _ir_value_with_context(expression: Any, context: dict[str, Any]) -> Any:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    if isinstance(value, IdentifierNode) and value.name in context:
        return context[value.name]
    if isinstance(value, BinaryExpressionNode):
        left = _ir_value_with_context(value.left, context)
        right = _ir_value_with_context(value.right, context)
        if isinstance(left, (int, float)) and isinstance(right, (int, float)):
            if value.operator == BinaryOperator.ADD:
                return left + right
            if value.operator == BinaryOperator.SUBTRACT:
                return left - right
            if value.operator == BinaryOperator.MULTIPLY:
                return left * right
            if value.operator == BinaryOperator.DIVIDE and right != 0:
                return left / right
            if value.operator == BinaryOperator.MODULO and right != 0:
                return left % right
    return _ir_value(expression)


def _enum_variant_ir(value: Any) -> dict[str, Any] | None:
    if isinstance(value, MemberAccessNode) and isinstance(value.object, IdentifierNode):
        return {
            "node_type": "EnumVariantIRNode",
            "enum_name": value.object.name,
            "variant_name": value.member,
        }
    if isinstance(value, EnumValuePatternNode):
        return {
            "node_type": "EnumVariantIRNode",
            "enum_name": value.enum_name,
            "variant_name": value.value_name,
        }
    return None


def _enum_variant_reference(value: Any) -> dict[str, Any] | None:
    enum_value = _enum_variant_ir(value)
    if enum_value is None:
        return None
    return {
        "node_type": "EnumVariantReferenceNode",
        "enum_name": enum_value["enum_name"],
        "variant_name": enum_value["variant_name"],
        "qualified_name": f"{enum_value['enum_name']}.{enum_value['variant_name']}",
    }


def _enum_symbols(module: ModuleNode) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for node in module.body:
        if not isinstance(node, EnumDeclarationNode):
            continue
        result.append(
            {
                "symbol_type": "EnumSymbol",
                "enum_name": node.name,
                "qualified_name": node.name,
            }
        )
        for value in node.values:
            result.append(
                {
                    "symbol_type": "EnumVariantSymbol",
                    "enum_name": node.name,
                    "variant_name": value.name,
                    "qualified_name": f"{node.name}.{value.name}",
                }
            )
    return result


def _type_label(value: Any) -> str | None:
    if value is None:
        return None
    encoded = to_json_value(value)
    if isinstance(encoded, dict):
        if encoded.get("node_type") == "PrimitiveTypeNode":
            return str(encoded.get("kind", "")).lower()
        if encoded.get("node_type") == "NamedTypeNode":
            return str(encoded.get("name"))
    return str(encoded)


def _reasoning_types(module: ModuleNode) -> list[str]:
    result: list[str] = []
    for call in _walk_runtime_calls(module):
        if not call.arguments:
            continue
        reasoning_type = _reasoning_type_for_operation(call.method, call.arguments[0])
        if reasoning_type not in result:
            result.append(reasoning_type)
    return result


def _reasoning_declarations(module: ModuleNode) -> dict[str, list[Any]]:
    return {
        "goals": [
            to_json_value(node) for node in module.body if isinstance(node, GoalNode)
        ],
        "states": [
            to_json_value(node)
            for node in module.body
            if isinstance(node, StateDeclarationNode)
        ],
        "constraints": [
            to_json_value(node)
            for node in module.body
            if isinstance(node, ConstraintNode)
        ],
        "reason_graphs": [
            to_json_value(node)
            for node in module.body
            if isinstance(node, ReasonGraphDeclarationNode)
        ],
        "execution_plans": [
            to_json_value(node)
            for node in module.body
            if isinstance(node, ExecutionPlanDeclarationNode)
        ],
    }


def _reasoning_type_for_operation(method: str, argument: Any) -> str:
    if method in {"search", "plan"}:
        return "goal"
    if method == "predict":
        return "state"
    if method == "simulate":
        return "execution_plan"
    return _reasoning_type_from_argument(argument)


def _reasoning_type_from_argument(argument: Any) -> str:
    name = getattr(argument, "name", None)
    type_name = getattr(argument, "type_name", None)
    text = str(type_name or name or "").lower()
    if "constraint" in text:
        return "constraint"
    if "graph" in text:
        return "reason_graph"
    if "plan" in text:
        return "execution_plan"
    if "state" in text:
        return "state"
    return "goal"


def _topological_calculations(module: ModuleNode) -> tuple[CalculationNode, ...]:
    by_name = {
        node.name: node for node in module.body if isinstance(node, CalculationNode)
    }
    dependencies = _calculation_dependencies(module)
    ready = sorted(name for name in by_name if not dependencies[name])
    ordered: list[CalculationNode] = []
    while ready:
        name = ready.pop(0)
        ordered.append(by_name[name])
        for candidate in sorted(dependencies):
            if name in dependencies[candidate]:
                dependencies[candidate].remove(name)
                if not dependencies[candidate]:
                    ready.append(candidate)
                    ready.sort()
        dependencies.pop(name, None)
    if dependencies:
        cycle = ", ".join(sorted(dependencies))
        raise SurfaceValidationError(f"CAL-030 Dependency Cycle Detected: {cycle}")
    return tuple(ordered)


def _calculation_dependencies(module: ModuleNode) -> dict[str, set[str]]:
    calculations = {
        node.name: node for node in module.body if isinstance(node, CalculationNode)
    }
    calculation_names = set(calculations)
    return {
        name: _dependencies_for_calculation(node, calculation_names)
        for name, node in calculations.items()
    }


def _dependencies_for_calculation(
    calculation: CalculationNode, calculation_names: set[str]
) -> set[str]:
    local_names: set[str] = set()
    dependencies: set[str] = set()
    for statement in calculation.body:
        expression = _statement_expression(statement)
        if expression is not None:
            dependencies.update(
                reference
                for reference in _expression_identifiers(expression)
                if reference in calculation_names and reference not in local_names
            )
        if isinstance(statement, (LetStatementNode, ConstStatementNode)):
            local_names.add(statement.identifier)
        elif isinstance(statement, AssignmentStatementNode):
            local_names.add(statement.target)
    dependencies.discard(calculation.name)
    return dependencies


def _statement_expression(statement: Any) -> ExpressionNode | None:
    if isinstance(
        statement,
        (
            LetStatementNode,
            ConstStatementNode,
            AssignmentStatementNode,
            ResultStatementNode,
            ExpressionStatementNode,
        ),
    ):
        return statement.expression
    if isinstance(statement, FieldAssignmentStatementNode):
        return statement.expression
    if isinstance(statement, IndexAssignmentStatementNode):
        return statement.expression
    return None


def _resolved_expression_inputs(
    expression: ExpressionNode | None,
    *,
    calculation: str,
    calculation_names: set[str],
    local_names: set[str],
) -> list[str]:
    if expression is None:
        return []
    inputs: list[str] = []
    for reference in sorted(_expression_identifiers(expression)):
        if reference in calculation_names and reference not in local_names:
            inputs.append(f"{reference}.state.result")
        elif reference in local_names:
            inputs.append(f"{calculation}.state.{reference}")
        else:
            inputs.append(reference)
    return inputs


def _expression_identifiers(expression: ExpressionNode | Any) -> set[str]:
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    found: set[str] = set()

    def visit(item: Any) -> None:
        if isinstance(item, IdentifierNode):
            found.add(item.name)
            return
        if isinstance(item, QualifiedIdentifierNode):
            return
        if isinstance(item, RuntimeNamespaceNode):
            return
        if isinstance(item, RuntimeCallExpressionNode):
            for argument in item.arguments:
                visit(argument)
            return
        if isinstance(item, UnaryExpressionNode):
            visit(item.operand)
            return
        if isinstance(
            item,
            (
                BinaryExpressionNode,
                ComparisonExpressionNode,
                LogicalExpressionNode,
            ),
        ):
            visit(item.left)
            visit(item.right)
            return
        if isinstance(item, ParenthesizedExpressionNode):
            visit(item.expression)
            return
        if isinstance(item, MemberAccessNode):
            visit(item.object)
            return
        if isinstance(item, CallExpressionNode):
            visit(item.callee)
            for argument in item.arguments:
                visit(argument)
            return
        if isinstance(item, StructLiteralNode):
            for field in item.fields:
                visit(field.expression)
            return
        if isinstance(item, (ArrayLiteralNode, TupleLiteralNode, SetLiteralNode)):
            for element in item.elements:
                visit(element)
            return
        if isinstance(item, MapLiteralNode):
            for entry in item.entries:
                visit(entry.key)
                visit(entry.value)
            return
        if isinstance(item, IndexAccessNode):
            visit(item.collection)
            visit(item.index)
            return
        if isinstance(item, SomeExpressionNode):
            visit(item.value)

    visit(value)
    return found


def _expression_function_calls(expression: ExpressionNode | Any | None) -> list[str]:
    if expression is None:
        return []
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    found: list[str] = []

    def visit(item: Any) -> None:
        if isinstance(item, CallExpressionNode):
            for argument in item.arguments:
                visit(argument)
            visit(item.callee)
            if isinstance(item.callee, IdentifierNode) and item.callee.name not in found:
                found.append(item.callee.name)
            return
        if isinstance(item, ExpressionNode):
            visit(item.expression)
            return
        if isinstance(item, RuntimeCallExpressionNode):
            for argument in item.arguments:
                visit(argument)
            return
        if isinstance(item, UnaryExpressionNode):
            visit(item.operand)
            return
        if isinstance(
            item,
            (
                BinaryExpressionNode,
                ComparisonExpressionNode,
                LogicalExpressionNode,
            ),
        ):
            visit(item.left)
            visit(item.right)
            return
        if isinstance(item, ParenthesizedExpressionNode):
            visit(item.expression)
            return
        if isinstance(item, MemberAccessNode):
            visit(item.object)
            return
        if isinstance(item, StructLiteralNode):
            for field in item.fields:
                visit(field.expression)
            return
        if isinstance(item, (ArrayLiteralNode, TupleLiteralNode, SetLiteralNode)):
            for element in item.elements:
                visit(element)
            return
        if isinstance(item, MapLiteralNode):
            for entry in item.entries:
                visit(entry.key)
                visit(entry.value)
            return
        if isinstance(item, IndexAccessNode):
            visit(item.collection)
            visit(item.index)
            return
        if isinstance(item, SomeExpressionNode):
            visit(item.value)

    visit(value)
    return found


def _function_call_arguments(
    expression: ExpressionNode | Any | None,
    function_name: str,
) -> list[ExpressionNode]:
    if expression is None:
        return []
    value = expression.expression if isinstance(expression, ExpressionNode) else expression
    found: list[ExpressionNode] = []

    def visit(item: Any) -> None:
        if isinstance(item, CallExpressionNode):
            if isinstance(item.callee, IdentifierNode) and item.callee.name == function_name:
                found.extend(item.arguments)
            for argument in item.arguments:
                visit(argument)
            return
        if isinstance(item, ExpressionNode):
            visit(item.expression)
            return
        if isinstance(item, (UnaryExpressionNode, ParenthesizedExpressionNode, SomeExpressionNode)):
            visit(getattr(item, "operand", getattr(item, "expression", getattr(item, "value", None))))
            return
        if isinstance(item, (BinaryExpressionNode, ComparisonExpressionNode, LogicalExpressionNode)):
            visit(item.left)
            visit(item.right)
            return
        if isinstance(item, MemberAccessNode):
            visit(item.object)
            return
        if isinstance(item, RuntimeCallExpressionNode):
            for argument in item.arguments:
                visit(argument)
            return
        if isinstance(item, StructLiteralNode):
            for field in item.fields:
                visit(field.expression)
            return
        if isinstance(item, (ArrayLiteralNode, TupleLiteralNode, SetLiteralNode)):
            for element in item.elements:
                visit(element)
            return
        if isinstance(item, MapLiteralNode):
            for entry in item.entries:
                visit(entry.key)
                visit(entry.value)
            return
        if isinstance(item, IndexAccessNode):
            visit(item.collection)
            visit(item.index)

    visit(value)
    return found


def _walk_runtime_calls(value: Any):
    if isinstance(value, RuntimeCallExpressionNode):
        yield value
        for argument in value.arguments:
            yield from _walk_runtime_calls(argument)
        return
    if isinstance(value, tuple):
        for item in value:
            yield from _walk_runtime_calls(item)
        return
    if isinstance(value, list):
        for item in value:
            yield from _walk_runtime_calls(item)
        return
    if hasattr(value, "__dataclass_fields__"):
        for field in value.__dataclass_fields__:
            yield from _walk_runtime_calls(getattr(value, field))


def compile_program(program: ProgramNode) -> tuple[dict[str, Any], ...]:
    return tuple(compile_semantic(module) for module in project_program(program))


def execution_plan_for(reason_ir: dict[str, Any]) -> dict[str, Any]:
    steps = [
        {
            "step_id": f"step-{index}",
            "transition_id": transition["transition_id"],
            "source": transition["source"],
            "target": transition["target"],
        }
        for index, transition in enumerate(reason_ir["transitions"], 1)
    ]
    result = {
        "selected_steps": steps,
        "alternative_paths": [],
        "expected_cost": sum(
            transition["expected_cost"] for transition in reason_ir["transitions"]
        ),
        "evidence_refs": [],
        "planner_version": "language-surface-validation/0.1",
    }
    bindings = reason_ir.get("metadata", {}).get("reason_object_bindings", [])
    if bindings:
        result["reason_object_plan"] = {
            "load_profile": "lazy_verified",
            "bindings": bindings,
            "steps": [
                {"order": index, "operation": operation, "transaction_boundary": operation in {"transaction_commit_or_rollback", "save"}}
                for index, operation in enumerate(["binding_resolution", "capability_validation", "native_load", "operation_execution", "transaction_commit_or_rollback", "projection_or_save"], 1)
            ],
            "resource_limits_required": True,
            "operations": reason_ir.get("metadata", {}).get("reason_object_operations", []),
        }
    vision_plan = reason_ir.get("metadata", {}).get("vision_execution_plan")
    if vision_plan:
        result["vision_plan"] = vision_plan
    return result


def _calculation_transition_id(
    calculation_name: str,
    statement_index: int,
    identifier: str,
    transition_index: int,
    current_sources: list[str],
) -> str:
    base = f"{calculation_name}-{statement_index}-{identifier}"
    if len(current_sources) == 1:
        return base
    return f"{base}-{transition_index}"


def _expression_relation(expression: ExpressionNode) -> str:
    value = expression.expression
    if isinstance(value, BinaryExpressionNode):
        return {
            BinaryOperator.ADD: "AddTransition",
            BinaryOperator.SUBTRACT: "SubtractTransition",
            BinaryOperator.MULTIPLY: "MultiplyTransition",
            BinaryOperator.DIVIDE: "DivideTransition",
            BinaryOperator.MODULO: "ModuloTransition",
        }[value.operator]
    if isinstance(value, ComparisonExpressionNode):
        return "CompareTransition"
    if isinstance(value, LogicalExpressionNode):
        return "LogicalTransition"
    if isinstance(value, UnaryExpressionNode):
        return "UnaryTransition"
    if isinstance(value, MemberAccessNode):
        return "MemberAccessTransition"
    if isinstance(value, IndexAccessNode):
        return "IndexAccessTransition"
    if isinstance(value, StructLiteralNode):
        return "StructLiteralTransition"
    if isinstance(value, ArrayLiteralNode):
        return "ArrayTransition"
    if isinstance(value, TupleLiteralNode):
        return "TupleTransition"
    if isinstance(value, SetLiteralNode):
        return "SetTransition"
    if isinstance(value, MapLiteralNode):
        return "MapTransition"
    if isinstance(value, SomeExpressionNode):
        return "SomeTransition"
    if isinstance(value, NoneLiteralNode):
        return "NoneTransition"
    if isinstance(value, CallExpressionNode):
        return "CallTransition"
    if isinstance(value, RuntimeCallExpressionNode):
        return {
            RuntimeCallKind.INPUT: "InputOperation",
            RuntimeCallKind.PRINT: "PrintOperation",
            RuntimeCallKind.SEARCH: "RuntimeSearchOperation",
            RuntimeCallKind.SIMULATION: "RuntimeSimulateOperation",
            RuntimeCallKind.PREDICTION: "RuntimePredictOperation",
            RuntimeCallKind.PLANNING: "RuntimePlanOperation",
        }[value.kind]
    return "ExpressionTransition"


def _runtime_source_state(argument: Any) -> str:
    if isinstance(argument, IdentifierNode):
        return argument.name
    if isinstance(argument, QualifiedIdentifierNode):
        return "::".join((*argument.path, argument.symbol))
    return str(to_json_value(argument))


def _statement_projection(
    statement: Any, index: int
) -> tuple[str, dict[str, Any], str]:
    if isinstance(statement, LetStatementNode):
        return (
            statement.identifier,
            to_json_value(statement),
            _expression_relation(statement.expression),
        )
    if isinstance(statement, ConstStatementNode):
        return (
            statement.identifier,
            to_json_value(statement),
            _expression_relation(statement.expression),
        )
    if isinstance(statement, AssignmentStatementNode):
        return (
            statement.target,
            to_json_value(statement),
            "StateUpdateTransition",
        )
    if isinstance(statement, FieldAssignmentStatementNode):
        return (
            "field_assignment",
            to_json_value(statement),
            "FieldAssignmentTransition",
        )
    if isinstance(statement, IndexAssignmentStatementNode):
        return (
            "index_assignment",
            to_json_value(statement),
            "IndexAssignmentTransition",
        )
    if isinstance(statement, ResultStatementNode):
        return (
            "result",
            to_json_value(statement),
            "ResultTransition",
        )
    if isinstance(statement, ReturnStatementNode):
        return (
            "return",
            to_json_value(statement),
            "ReturnTransition",
        )
    if isinstance(statement, ExpressionStatementNode):
        return (
            f"expression_{index}",
            to_json_value(statement),
            "CallTransition",
        )
    if isinstance(statement, ForStatementNode):
        return (f"for_{index}", to_json_value(statement), "ForTransition")
    if isinstance(statement, WhileStatementNode):
        return (f"while_{index}", to_json_value(statement), "WhileTransition")
    if isinstance(statement, LoopStatementNode):
        return (f"loop_{index}", to_json_value(statement), "LoopTransition")
    if isinstance(statement, BreakStatementNode):
        return (f"break_{index}", to_json_value(statement), "BreakTransition")
    if isinstance(statement, ContinueStatementNode):
        return (f"continue_{index}", to_json_value(statement), "ContinueTransition")
    if isinstance(statement, IfStatementNode):
        return (f"if_{index}", to_json_value(statement), "DecisionTransition")
    return (
        f"match_{index}",
        to_json_value(statement),
        "DecisionTransition",
    )


def _terminates_with_result(statement: Any) -> bool:
    if isinstance(statement, ResultStatementNode):
        return True
    if isinstance(statement, IfStatementNode):
        if statement.else_branch is None:
            return False
        branches = [statement.body]
        branches.extend(branch.body for branch in statement.elif_branches)
        branches.append(statement.else_branch.body)
        return all(
            body and _terminates_with_result(body[-1]) for body in branches
        )
    if hasattr(statement, "arms"):
        return bool(statement.arms) and all(
            arm.body and _terminates_with_result(arm.body[-1])
            for arm in statement.arms
        )
    return False
