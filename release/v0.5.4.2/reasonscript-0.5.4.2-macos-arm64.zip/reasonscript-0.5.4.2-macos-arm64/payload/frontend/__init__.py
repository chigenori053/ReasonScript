"""ReasonScript language frontend foundations."""
