# ReasonScriptV5.2

ReasonScript 0.5.2のmacOS Apple Silicon（arm64）向け正式配布パッケージです。
VisionRuntimeと`reason-vision`を収録します。

## 新規インストール

内側のアーカイブを展開し、展開先で次を実行します。

```sh
python3 payload/scripts/install_common.py --non-interactive --json
```

任意のインストール先には`--prefix <path>`を追加します。ビルド済みの
`reason-vision`と`reason-updater`を使用するため、対象環境にRust/Cargoは
不要です。Python 3.11以降が必要です。

## 検証

- Version: `0.5.2`
- Package class: `release`
- Source commit: `0bff1bc99bf69bec902f3eba9ab4ea1c56b36447`
- Package self-validation: PASS
- Full CI: PASS（1085 tests）
- Fresh-install validation: 36/36 PASS
- Native VisionRuntime: PASS（`unsafe_blocks: 0`）
- Vision `.rsn` to RUO/Tensor smoke: PASS

このパッケージはコミット済みのクリーンなソースツリーから生成されています。
