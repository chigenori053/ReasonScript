//! `reason-runtime-host` -- versioned ReasonScript execution host.
//!
//! Reads a `reasonscript-runtime-request/1.0` envelope (file path argument,
//! or `-` for stdin), executes its computation IR, and returns a
//! `reasonscript-runtime-result/1.0` envelope. Raw
//! `reason-computation-ir/0.1` remains accepted during migration.
//!
//! ```json
//! {"ok": true, "calculation_results": {"Answer": 3.5}}
//! {"ok": false, "error_code": "RT-ARITH-001", "error_message": "..."}
//! ```
//!
//! This shape is deliberately simple JSON (not the full
//! `reasonscript-integrated-runtime/0.1` envelope the Python side emits)
//! so `frontend.computation_ir`'s differential tests can decode it with
//! plain `json.loads` and compare `calculation_results` against the
//! Python IR interpreter's output for the same program.

use std::env;
use std::fs;
use std::io::{self, Read};
use std::process::ExitCode;

use reasonscript_computation_ir::causal::{
    evaluate as evaluate_causal, CausalConfig, CausalMode, CausalObservation,
};
use reasonscript_computation_ir::causal_bridge::{
    external as external_causal, merge as merge_causal, CausalObservationSource,
};
use reasonscript_computation_ir::reason_structure::{ExecutableMode, ReasonUnitMode};
use reasonscript_computation_ir::reasoning_state::ReasoningStateMode;
use reasonscript_computation_ir::state_causality::StateCausalityMode;
use reasonscript_computation_ir::state_trace::{TraceConfig, TraceMode};
use reasonscript_computation_ir::{
    decode, to_json, NumericMode, TensorPolicy, Vm, DEFAULT_MAX_CALL_DEPTH,
    DEFAULT_MAX_LOOP_ITERATIONS,
};

const REQUEST_SCHEMA: &str = "reasonscript-runtime-request/1.0";
const RESULT_SCHEMA: &str = "reasonscript-runtime-result/1.0";
const HOST_PROFILE: &str = "reasonscript-runtime-host/1.0";

fn main() -> ExitCode {
    // Phase 4 ("制御された再帰"): `Vm::call_function` recurses natively
    // (`call_function` -> `run_function` -> `eval_expr` -> ...) rather
    // than trampolining, so `max_call_depth`'s check is only the actual,
    // deterministic limit on recursion if the executing thread has
    // enough native stack to reach that depth without overflowing (a
    // hard process abort, not the stable `RT-CALL-003` diagnostic the
    // check is meant to produce) first. A thread's default stack size
    // varies by platform and caller -- run on an explicitly-sized one so
    // that stays true regardless of what stack size the calling context
    // happens to provide, rather than depending on the OS process
    // default being generous enough.
    const STACK_SIZE: usize = 64 * 1024 * 1024;
    std::thread::Builder::new()
        .stack_size(STACK_SIZE)
        .spawn(run_main)
        .expect("failed to spawn runtime-host worker thread")
        .join()
        .expect("runtime-host worker thread panicked")
}

fn run_main() -> ExitCode {
    let path = env::args().nth(1);
    if path.as_deref() == Some("verify-native") {
        println!(
            "{}",
            serde_json::json!({
                "ok": true,
                "profile": HOST_PROFILE,
                "request_schema": REQUEST_SCHEMA,
                "result_schema": RESULT_SCHEMA,
                "unsafe_blocks": 0,
            })
        );
        return ExitCode::SUCCESS;
    }
    let source = match read_source(path.as_deref()) {
        Ok(source) => source,
        Err(message) => return fail_io(&message),
    };

    let document: serde_json::Value = match serde_json::from_str(&source) {
        Ok(value) => value,
        Err(error) => return fail("IR-DECODE-001", &error.to_string()),
    };
    if document.get("schema").and_then(serde_json::Value::as_str) == Some(REQUEST_SCHEMA) {
        return run_request(&document);
    }

    run_legacy(&source)
}

fn run_legacy(source: &str) -> ExitCode {
    let program = match decode(source) {
        Ok(program) => program,
        Err(error) => return fail("IR-DECODE-001", &error.to_string()),
    };

    let vm = Vm::with_numeric_mode(&program, numeric_mode_from_env());
    match vm.run_calculations(&program) {
        Ok(calculations) => {
            let mut results = serde_json::Map::new();
            for (name, value) in calculations {
                results.insert(name, to_json(&value));
            }
            let payload = serde_json::json!({
                "ok": true,
                "calculation_results": results,
                "console_output": vm.console_events(),
            });
            println!("{payload}");
            ExitCode::SUCCESS
        }
        Err(error) => fail(&error.code, &error.message),
    }
}

fn run_request(request: &serde_json::Value) -> ExitCode {
    let request_id = request
        .get("request_id")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("");
    if request_id.is_empty() {
        return fail_request(
            request_id,
            "RTH-PROTO-001",
            "runtime request_id must be a non-empty string",
        );
    }
    if request.get("operation").and_then(serde_json::Value::as_str) != Some("execute") {
        return fail_request(
            request_id,
            "RTH-PROTO-002",
            "runtime request operation must be execute",
        );
    }
    let Some(program_value) = request.get("program") else {
        return fail_request(
            request_id,
            "RTH-PROTO-003",
            "runtime request program is required",
        );
    };
    let Some(context) = request
        .get("context")
        .and_then(serde_json::Value::as_object)
    else {
        return fail_request(
            request_id,
            "RTH-PROTO-003",
            "runtime request context is required",
        );
    };
    if !context
        .get("capabilities")
        .is_some_and(serde_json::Value::is_object)
        || !context
            .get("limits")
            .is_some_and(serde_json::Value::is_object)
        || !context
            .get("trace")
            .is_some_and(serde_json::Value::is_object)
        || !context
            .get("resource_root")
            .is_some_and(serde_json::Value::is_string)
    {
        return fail_request(
            request_id,
            "RTH-PROTO-003",
            "runtime request context is malformed",
        );
    }
    let source = match serde_json::to_string(program_value) {
        Ok(value) => value,
        Err(error) => return fail_request(request_id, "RTH-PROTO-003", &error.to_string()),
    };
    let program = match decode(&source) {
        Ok(program) => program,
        Err(error) => return fail_request(request_id, "IR-DECODE-001", &error.to_string()),
    };
    let numeric_mode_name = request
        .pointer("/context/numeric_mode")
        .and_then(serde_json::Value::as_str);
    if !matches!(numeric_mode_name, Some("compat-reference" | "native-fast")) {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "numeric_mode must be compat-reference or native-fast",
        );
    }
    let numeric_mode = numeric_mode_from_name(numeric_mode_name.unwrap_or("compat-reference"));
    let limits = context
        .get("limits")
        .and_then(serde_json::Value::as_object)
        .unwrap();
    let mut tensor_policy = TensorPolicy::default();
    tensor_policy.max_rank = limit(limits, "max_rank", tensor_policy.max_rank);
    tensor_policy.max_elements = limit(limits, "max_elements", tensor_policy.max_elements);
    tensor_policy.max_tensor_bytes =
        limit(limits, "max_tensor_bytes", tensor_policy.max_tensor_bytes);
    tensor_policy.max_live_tensors =
        limit(limits, "max_live_tensors", tensor_policy.max_live_tensors);
    tensor_policy.max_shape_dimension = limit(
        limits,
        "max_shape_dimension",
        tensor_policy.max_shape_dimension,
    );
    tensor_policy.max_artifact_bytes = limit(
        limits,
        "max_artifact_bytes",
        tensor_policy.max_artifact_bytes,
    );
    tensor_policy.inline_elements = limit(limits, "inline_elements", tensor_policy.inline_elements);
    tensor_policy.max_autograd_nodes = limit(
        limits,
        "max_autograd_nodes",
        tensor_policy.max_autograd_nodes,
    );
    tensor_policy.max_saved_tensor_bytes = limit(
        limits,
        "max_saved_tensor_bytes",
        tensor_policy.max_saved_tensor_bytes,
    );
    let max_call_depth = limit(limits, "max_call_depth", DEFAULT_MAX_CALL_DEPTH as usize) as u32;
    let max_loop_iterations = limit(
        limits,
        "max_loop_iterations",
        DEFAULT_MAX_LOOP_ITERATIONS as usize,
    ) as u64;
    let capabilities = context
        .get("capabilities")
        .and_then(serde_json::Value::as_object)
        .unwrap();
    let filesystem_read = capabilities
        .get("filesystem_read")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false);
    let filesystem_write = capabilities
        .get("filesystem_write")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false);
    let trace_config = match TraceConfig::from_json(&request["context"]["trace"]) {
        Ok(config) => config,
        Err(error) => return fail_runtime_request(request_id, &error),
    };
    let trace_enabled = trace_config.mode != TraceMode::Off;
    let transport_tensors = request
        .pointer("/context/transport_tensors")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(false);
    let resource_root = std::path::PathBuf::from(
        context
            .get("resource_root")
            .and_then(serde_json::Value::as_str)
            .unwrap(),
    );
    let backend = context
        .get("backend")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("RuntimeReal")
        .to_owned();
    let mut vm = Vm::with_runtime_context(
        &program,
        numeric_mode,
        tensor_policy,
        resource_root,
        filesystem_read,
        filesystem_write,
        trace_enabled,
        backend,
        max_call_depth,
        max_loop_iterations,
    );
    let semantic_events = request
        .pointer("/context/reasoning/semantic_events")
        .and_then(serde_json::Value::as_bool)
        .unwrap_or(true);
    let reason_unit_name = request
        .pointer("/context/reason_units")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("off");
    let Some(reason_unit_mode) = ReasonUnitMode::parse(reason_unit_name) else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "reason_units must be off, ru, ru_rus, or ru_rus_ruo",
        );
    };
    let executable_reason_unit_name = request
        .pointer("/context/executable_reason_units")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("off");
    let Some(executable_reason_unit_mode) = ExecutableMode::parse(executable_reason_unit_name)
    else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "executable_reason_units must be off, count, or full",
        );
    };
    let state_causality_name = request
        .pointer("/context/state_causality")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("off");
    let Some(state_causality_mode) = StateCausalityMode::parse(state_causality_name) else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "state_causality must be off, trace, or full",
        );
    };
    if state_causality_mode.enabled() && executable_reason_unit_mode != ExecutableMode::Full {
        return fail_request(
            request_id,
            "STATE-CAUSAL-001",
            "state causality requires executable_reason_units=full",
        );
    }
    let reasoning_state_name = request
        .pointer("/context/reasoning_state")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("off");
    let Some(reasoning_state_mode) = ReasoningStateMode::parse(reasoning_state_name) else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "reasoning_state must be off or lightweight",
        );
    };
    if reasoning_state_mode.enabled() && executable_reason_unit_mode != ExecutableMode::Full {
        return fail_request(
            request_id,
            "RUS-005",
            "reasoning state requires executable_reason_units=full",
        );
    }
    let causal_mode_name = request
        .pointer("/context/causal_evaluation")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("off");
    let Some(causal_mode) = CausalMode::parse(causal_mode_name) else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "causal_evaluation must be off, dependency, counterfactual, or full",
        );
    };
    let causal_observations: Vec<CausalObservation> = match serde_json::from_value(
        request
            .pointer("/context/causal_observations")
            .cloned()
            .unwrap_or_else(|| serde_json::json!([])),
    ) {
        Ok(observations) => observations,
        Err(error) => return fail_request(request_id, "CAUSAL-001", &error.to_string()),
    };
    let causal_config = CausalConfig {
        mode: causal_mode,
        max_causal_depth: request
            .pointer("/context/max_causal_depth")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(8) as usize,
        max_counterfactual_runs: request
            .pointer("/context/max_counterfactual_runs")
            .and_then(serde_json::Value::as_u64)
            .unwrap_or(32) as usize,
    };
    let causal_source_name = request
        .pointer("/context/causal_observation_source")
        .and_then(serde_json::Value::as_str)
        .unwrap_or("external");
    let Some(causal_source) = CausalObservationSource::parse(causal_source_name) else {
        return fail_request(
            request_id,
            "RTH-PROTO-004",
            "causal_observation_source must be external, native, or merge",
        );
    };
    if matches!(
        causal_source,
        CausalObservationSource::Native | CausalObservationSource::Merge
    ) && executable_reason_unit_mode == ExecutableMode::Off
    {
        return fail_request(
            request_id,
            "CAUSAL-BRIDGE-007",
            "native causal observations require executable Reason Units",
        );
    }
    if matches!(
        causal_source,
        CausalObservationSource::Native | CausalObservationSource::Merge
    ) && executable_reason_unit_mode != ExecutableMode::Full
    {
        return fail_request(
            request_id,
            "CAUSAL-BRIDGE-008",
            "native causal observations require executable_reason_units=full",
        );
    }
    vm.configure_trace(trace_config, semantic_events);
    vm.configure_reason_units(reason_unit_mode);
    vm.configure_executable_reason_units(executable_reason_unit_mode);
    // State causality auto-enables the reasoning state, so set this first.
    vm.configure_reasoning_state(reasoning_state_mode);
    vm.configure_state_causality(state_causality_mode);
    let execution_started = Instant::now();
    match vm.run_calculations(&program) {
        Ok(calculations) => {
            let runtime_execution_ns = execution_started.elapsed().as_nanos() as u64;
            let causal_bridge = match causal_source {
                CausalObservationSource::External => external_causal(causal_observations),
                CausalObservationSource::Native => vm.causal_bridge(causal_source),
                CausalObservationSource::Merge => merge_causal(
                    vm.causal_bridge(CausalObservationSource::Native),
                    &causal_observations,
                ),
            };
            let state_causality = vm.state_causality_trace();
            let reasoning_state = vm.reasoning_state_trace();
            let mut causal_trace = evaluate_causal(&causal_bridge.observations, &causal_config);
            if state_causality_mode == StateCausalityMode::Full {
                causal_trace.extend_relations(state_causality.relations.clone());
            }
            causal_trace.metrics.normal_runtime_ns = runtime_execution_ns;
            causal_trace.metrics.counterfactual_cost_ratio = if runtime_execution_ns == 0 {
                None
            } else {
                Some(
                    causal_trace.metrics.counterfactual_runtime_ns as f64
                        / runtime_execution_ns as f64,
                )
            };
            let loop_trace = vm.loop_trace();
            let tensor_trace = vm.tensor_trace();
            let vision_trace = vm.vision_trace();
            let reasoning_trace = vm.reasoning_trace();
            let reason_structure_trace = vm.reason_structure_trace();
            let reason_unit_trace = vm.reason_unit_trace();
            let tensor_metadata = vm.tensor_metadata();
            let mut combined_trace = loop_trace.clone();
            combined_trace.extend(tensor_trace.clone());
            combined_trace.extend(vision_trace.clone());
            combined_trace.extend(reasoning_trace.clone());
            let mut results = serde_json::Map::new();
            for (name, value) in calculations {
                results.insert(
                    name,
                    if transport_tensors {
                        vm.transport_value(&value)
                    } else {
                        to_json(&value)
                    },
                );
            }
            let mut runtime_metrics = vm.runtime_metrics();
            if request
                .pointer("/context/benchmark_metrics")
                .and_then(serde_json::Value::as_bool)
                .unwrap_or(false)
            {
                runtime_metrics.as_object_mut().unwrap().extend([(
                    "runtime_execution_ns".to_owned(),
                    runtime_execution_ns.into(),
                )]);
            }
            println!(
                "{}",
                serde_json::json!({
                    "schema": RESULT_SCHEMA,
                    "request_id": request_id,
                    "ok": true,
                    "execution_mode": "rust",
                    "calculation_results": results,
                    "console_output": vm.console_events(),
                    "diagnostics": [],
                    "metadata": {
                        "host_profile": HOST_PROFILE,
                        "trace": combined_trace,
                        "loop_trace": loop_trace,
                        "tensor_trace": tensor_trace,
                        "vision_trace": vision_trace,
                        "reasoning_trace": reasoning_trace,
                        "reason_structure_trace": reason_structure_trace,
                        "reason_unit_trace": reason_unit_trace,
                        "causal_trace": causal_trace,
                        "causal_bridge": causal_bridge,
                        "state_causality": state_causality,
                        "reasoning_state": reasoning_state,
                        "tensor_metadata": tensor_metadata,
                        "console_output": vm.console_events(),
                        "reason_object_metadata": [],
                        "trace_diagnostics": vm.trace_diagnostics(),
                        "runtime_metrics": runtime_metrics,
                    },
                })
            );
            ExitCode::SUCCESS
        }
        Err(error) => fail_runtime_request(request_id, &error),
    }
}

fn limit(limits: &serde_json::Map<String, serde_json::Value>, name: &str, default: usize) -> usize {
    limits
        .get(name)
        .and_then(serde_json::Value::as_u64)
        .and_then(|value| usize::try_from(value).ok())
        .unwrap_or(default)
}

fn numeric_mode_from_name(name: &str) -> NumericMode {
    match name {
        "native-fast" => NumericMode::NativeFast,
        _ => NumericMode::CompatReference,
    }
}

/// Phase 9: `REASONSCRIPT_NUMERIC_MODE=native-fast` opts into real `f32`
/// rounding and the parallel/rayon op paths (see `NumericMode`'s doc
/// comment). Any other value (including unset) keeps the default,
/// unchanged `CompatReference` behavior.
fn numeric_mode_from_env() -> NumericMode {
    match env::var("REASONSCRIPT_NUMERIC_MODE").as_deref() {
        Ok("native-fast") => NumericMode::NativeFast,
        _ => NumericMode::CompatReference,
    }
}

fn read_source(path: Option<&str>) -> Result<String, String> {
    match path {
        None | Some("-") => {
            let mut buffer = String::new();
            io::stdin()
                .read_to_string(&mut buffer)
                .map_err(|error| error.to_string())?;
            Ok(buffer)
        }
        Some(path) => fs::read_to_string(path).map_err(|error| format!("{path}: {error}")),
    }
}

fn fail(code: &str, message: &str) -> ExitCode {
    let payload = serde_json::json!({
        "ok": false,
        "error_code": code,
        "error_message": message,
    });
    println!("{payload}");
    ExitCode::FAILURE
}

fn fail_io(message: &str) -> ExitCode {
    fail("IR-IO-001", message)
}

fn fail_request(request_id: &str, code: &str, message: &str) -> ExitCode {
    fail_request_with_location(request_id, code, message, None)
}

fn fail_runtime_request(
    request_id: &str,
    error: &reasonscript_computation_ir::RuntimeError,
) -> ExitCode {
    fail_request_with_location(
        request_id,
        &error.code,
        &error.message,
        error.source_location.clone(),
    )
}

fn fail_request_with_location(
    request_id: &str,
    code: &str,
    message: &str,
    source_location: Option<serde_json::Value>,
) -> ExitCode {
    let payload = serde_json::json!({
        "schema": RESULT_SCHEMA,
        "request_id": request_id,
        "ok": false,
        "execution_mode": "rust",
        "calculation_results": null,
        "diagnostics": [{
            "code": code,
            "severity": "error",
            "category": "runtime",
            "message": message,
            "source_location": source_location,
        }],
        "metadata": {
            "host_profile": HOST_PROFILE,
            "trace": [],
            "tensor_metadata": [],
            "reason_object_metadata": [],
        },
    });
    println!("{payload}");
    ExitCode::FAILURE
}
use std::time::Instant;
